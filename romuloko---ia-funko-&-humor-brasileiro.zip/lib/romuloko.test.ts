import test from "node:test";
import assert from "node:assert/strict";
import {
  ROMULOKO_SUGGESTIONS,
  ROMULOKO_THINKING_QUOTES,
  getRomulokoSystemInstruction,
  detectMoodFromContext,
} from "./romuloko";
import { prepareSpeechText } from "./audio-effects";

test("getRomulokoSystemInstruction defines the character ROMULOKO, Funko traits, and acid irreverent personality", () => {
  const instruction = getRomulokoSystemInstruction();
  assert.ok(instruction.includes("ROMULOKO"));
  assert.ok(instruction.includes("Funko Pop"));
  assert.ok(instruction.includes("camiseta bege"));
  assert.ok(instruction.includes("corrente"));
  assert.ok(instruction.includes("HUMOR ÁCIDO"));
  assert.ok(instruction.includes("PROVOCADOR E NADA PUXA-SACO"));
  assert.ok(instruction.includes("1 a 3 frases"));
  assert.ok(instruction.includes("carioca"));
});

test("prepareSpeechText strips prompts, instructions, markdown and returns exclusively spoken content", () => {
  const rawWithInstruction = "fale em tom carioca autêntico: Cilada, mermão, apaga esse histórico!";
  assert.equal(prepareSpeechText(rawWithInstruction), "Cilada, mermão, apaga esse histórico!");

  const rawWithMarkdown = "**Olha a audácia**, _meu consagrado_! #Partiu";
  assert.equal(prepareSpeechText(rawWithMarkdown), "Olha a audácia , meu consagrado ! Partiu");
});

test("detectMoodFromContext accurately identifies moods: pensando, rindo, debochando, surpreso, normal", () => {
  assert.equal(detectMoodFromContext("qualquer texto", true), "pensando");
  assert.equal(detectMoodFromContext("isso foi muito engraçado kkkk", false), "rindo");
  assert.equal(detectMoodFromContext("Eita! Não acredito!", false), "surpreso");
  assert.equal(detectMoodFromContext("me dá um conselho", false), "debochando");
  assert.equal(detectMoodFromContext("ola tudo bem", false), "normal");
});

test("ROMULOKO_SUGGESTIONS provides fast starter questions", () => {
  assert.ok(ROMULOKO_SUGGESTIONS.length >= 4);
  assert.ok(ROMULOKO_SUGGESTIONS.some((s) => s.prompt.includes("Romuloko")));
});

test("ROMULOKO_THINKING_QUOTES contains animated thinking banter", () => {
  assert.ok(ROMULOKO_THINKING_QUOTES.length >= 4);
  assert.ok(ROMULOKO_THINKING_QUOTES.some((q) => q.includes("Romuloko") || q.includes("mico")));
});
