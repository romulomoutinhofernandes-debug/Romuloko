import test from "node:test";
import assert from "node:assert/strict";
import {
  CHAOS_MODES,
  SUGGESTIONS,
  POPULAR_CASES,
  validateChaosMode,
  getSystemInstructionForMode,
  formatBanterForMode,
} from "./chaos-modes";

test("CHAOS_MODES contains all 4 requested personality levels", () => {
  const modeIds = Object.keys(CHAOS_MODES);
  assert.equal(modeIds.length, 4);
  assert.ok(modeIds.includes("debochado"));
  assert.ok(modeIds.includes("sincerao"));
  assert.ok(modeIds.includes("duvidoso"));
  assert.ok(modeIds.includes("caos"));
});

test("validateChaosMode defaults to debochado when input is invalid or missing", () => {
  assert.equal(validateChaosMode(undefined), "debochado");
  assert.equal(validateChaosMode(null), "debochado");
  assert.equal(validateChaosMode("invalid-mode"), "debochado");
  assert.equal(validateChaosMode("caos"), "caos");
  assert.equal(validateChaosMode("sincerao"), "sincerao");
});

test("getSystemInstructionForMode includes Funko Pop character description and mode specific guidelines", () => {
  const instruction = getSystemInstructionForMode("debochado");
  assert.ok(instruction.includes("RESENDE"));
  assert.ok(instruction.includes("Funko Pop"));
  assert.ok(instruction.includes("camiseta bege"));
  assert.ok(instruction.includes("corrente prateada"));
  assert.ok(instruction.includes("DEBOCHADO"));

  const caosInstruction = getSystemInstructionForMode("caos");
  assert.ok(caosInstruction.includes("CAOS TOTAL"));
});

test("SUGGESTIONS contains required prompt questions", () => {
  const titles = SUGGESTIONS.map((s) => s.title);
  assert.ok(titles.some((t) => t.includes("conselho amoroso")));
  assert.ok(titles.some((t) => t.includes("humilha com carinho")));
  assert.ok(titles.some((t) => t.includes("Por que minha vida é assim?")));
  assert.ok(titles.some((t) => t.includes("verdade que dói")));
});

test("formatBanterForMode returns at least 2 funny quotes per mode", () => {
  const banter = formatBanterForMode("sincerao");
  assert.ok(Array.isArray(banter));
  assert.ok(banter.length >= 2);
  assert.ok(banter[0].length > 5);
});
