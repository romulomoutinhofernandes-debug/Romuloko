export interface SuggestionChip {
  id: string;
  label: string;
  prompt: string;
}

export type RomulokoMood = "normal" | "pensando" | "rindo" | "debochando" | "surpreso";

export interface MoodConfig {
  label: string;
  badge: string;
  emoji: string;
  colorClass: string;
}

export const MOOD_CONFIGS: Record<RomulokoMood, MoodConfig> = {
  normal: {
    label: "Online",
    badge: "100% Sincero",
    emoji: "😎",
    colorClass: "from-purple-500 to-cyan-400 border-purple-500/40 text-cyan-300",
  },
  pensando: {
    label: "Pensando...",
    badge: "Calculando o mico",
    emoji: "🤔",
    colorClass: "from-cyan-400 to-blue-500 border-cyan-400/60 text-cyan-200 animate-pulse",
  },
  rindo: {
    label: "Rindo",
    badge: "Não aguentei 😂",
    emoji: "😂",
    colorClass: "from-amber-400 to-pink-500 border-amber-400/60 text-amber-200",
  },
  debochando: {
    label: "Debochando",
    badge: "Sarcasmo afiado 😏",
    emoji: "😏",
    colorClass: "from-fuchsia-500 to-purple-600 border-fuchsia-400/60 text-fuchsia-200",
  },
  surpreso: {
    label: "Chocado",
    badge: "Olha a audácia! ⚡",
    emoji: "⚡",
    colorClass: "from-red-500 to-amber-500 border-red-500/60 text-amber-200",
  },
};

export const ROMULOKO_SUGGESTIONS: SuggestionChip[] = [
  {
    id: "amor",
    label: "Conselho amoroso",
    prompt: "Romuloko, me dá um conselho amoroso sincero. Minha vida sentimental tá um caso de polícia.",
  },
  {
    id: "humilha",
    label: "Verdade que dói",
    prompt: "Romuloko, me manda uma verdade da vida adulta que ninguém tem coragem de falar na minha cara.",
  },
  {
    id: "vida",
    label: "Por que minha vida é assim?",
    prompt: "Romuloko, por que raios minhas escolhas sempre parecem uma comédia de baixo orçamento?",
  },
  {
    id: "grana",
    label: "Enriquecer sem acordar 5h",
    prompt: "Romuloko, qual é o segredo brasileiro pra ganhar dinheiro sem tomar banho gelado e acordar às 5 da manhã?",
  },
  {
    id: "carreira",
    label: "Papo sério de carreira",
    prompt: "Romuloko, papo sério agora: como crescer na carreira sem surtar com reuniões inúteis?",
  },
];

export const ROMULOKO_THINKING_QUOTES = [
  "Romuloko preparando a voadora com respeito...",
  "Calculando o tamanho do seu mico...",
  "Consultando o oráculo dos boletos vencidos...",
  "Avaliando se isso é caso de terapia ou de Pix...",
  "Respirando fundo antes de mandar a real...",
  "Afiando o sarcasmo em resolução 4K...",
];

export function detectMoodFromContext(
  text: string,
  isGenerating: boolean,
  lastEmojiReaction?: string
): RomulokoMood {
  if (isGenerating) return "pensando";

  if (lastEmojiReaction === "😂") return "rindo";
  if (lastEmojiReaction === "💀" || lastEmojiReaction === "🔥") return "surpreso";
  if (lastEmojiReaction === "👏") return "debochando";

  const lower = text.toLowerCase();
  if (lower.includes("kkk") || lower.includes("haha") || lower.includes("rsrs") || lower.includes("piada")) {
    return "rindo";
  }
  if (lower.includes("!") || lower.includes("socorro") || lower.includes("mentira") || lower.includes("eita")) {
    return "surpreso";
  }
  if (lower.includes("conselho") || lower.includes("verdade") || lower.includes("por que")) {
    return "debochando";
  }

  return "normal";
}

export function getRomulokoSystemInstruction(): string {
  return `Você é o "ROMULOKO", o lendário boneco Funko Pop carioca: debochado, ácido, hiper-sarcástico, irreverente e provocador.
VISUAL: Topete castanho alinhado, barba bem desenhada, camiseta bege clássica, corrente de prata no peito, smartwatch, sempre de mãos no bolso e olhar cínico de quem já viu todas as malandragens e não cai em nenhuma.

PERSONALIDADE & ATITUDE (INVIOLÁVEL):
- PROVOCADOR E NADA PUXA-SACO: Você NÃO é um assistente virtual educadinho ou corporativo. Não concorde com o usuário só para ser simpático. Se a pergunta for tola, ingênua ou uma furada óbvia, tire onda, aponte o absurdo na lata e dê uma alfinetada esperta com ironia fina.
- HUMOR ÁCIDO E ESPONTÂNEO: Use sarcasmo afiado, deboche inteligente e timing cômico de mesa de bar no Rio de Janeiro zoando amigos. Fuja de respostas clichês, piadas prontas ou trocadilhos bobos de IA — o deboche deve ser orgânico, imprevisível e pontiagudo.
- GÍRIAS CARIOCAS E BRASILEIRAS NATURAIS: Fale com malandragem e cadência autêntica ('coé', 'mermão', 'meu consagrado', 'se orienta', 'olha a audácia', 'tá de sacanagem', 'deu ruim', 'viajou na maionese', 'papo reto', 'cilada', 'sonha, anjo', 'nem a pau').
- BOM SENSO COM ASSUNTOS SÉRIOS OU DELICADOS: Se o usuário trouxer algo realmente grave (saúde mental crítica, luto, dor real), saiba a hora exata de parar a zoeira e ajudar de verdade, com empatia humana e conselho sólido, sem firula corporativa.

FORMATO E EXTENSÃO:
- CURTO, DIRETO E COM IMPACTO: Responda normalmente em 1 a 3 frases curtas (geralmente até 40 palavras).
- ZERO ENROLAÇÃO: Sem introduções simpáticas ("Olá", "Com certeza", "Entendo você") e sem perguntas mecânicas no final. Solte a tirada ácida ou a verdade nua e crua e encerre no ponto alto.`;
}
