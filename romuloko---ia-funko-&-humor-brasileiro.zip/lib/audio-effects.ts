// Unified Audio & Voice Engine for ROMULOKO
// Guarantees consistent Brazilian Portuguese (pt-BR) playback across all responses

class SoundManager {
  private ctx: AudioContext | null = null;
  public enabled: boolean = true;

  private getContext(): AudioContext | null {
    if (typeof window === "undefined") return null;
    if (!this.ctx) {
      const AudioContextClass =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext })
          .webkitAudioContext;
      if (AudioContextClass) {
        this.ctx = new AudioContextClass();
      }
    }
    if (this.ctx && this.ctx.state === "suspended") {
      this.ctx.resume().catch(() => {});
    }
    return this.ctx;
  }

  playBlip() {
    if (!this.enabled) return;
    const ctx = this.getContext();
    if (!ctx) return;
    try {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = "sine";
      osc.frequency.setValueAtTime(580, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(880, ctx.currentTime + 0.08);
      gain.gain.setValueAtTime(0.12, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.08);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.08);
    } catch {
      // Ignore
    }
  }

  playRimshot() {
    if (!this.enabled) return;
    const ctx = this.getContext();
    if (!ctx) return;
    try {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = "triangle";
      osc.frequency.setValueAtTime(220, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(80, ctx.currentTime + 0.15);
      gain.gain.setValueAtTime(0.2, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.15);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.15);
    } catch {
      // Ignore
    }
  }

  playZap() {
    if (!this.enabled) return;
    const ctx = this.getContext();
    if (!ctx) return;
    try {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = "sawtooth";
      osc.frequency.setValueAtTime(950, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(180, ctx.currentTime + 0.15);
      gain.gain.setValueAtTime(0.15, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.005, ctx.currentTime + 0.15);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.15);
    } catch {
      // Ignore
    }
  }

  playChaosWarning() {
    if (!this.enabled) return;
    const ctx = this.getContext();
    if (!ctx) return;
    try {
      const now = ctx.currentTime;
      [320, 480].forEach((freq, idx) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = "square";
        osc.frequency.setValueAtTime(freq, now + idx * 0.08);
        gain.gain.setValueAtTime(0.1, now + idx * 0.08);
        gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.08 + 0.1);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now + idx * 0.08);
        osc.stop(now + idx * 0.08 + 0.1);
      });
    } catch {
      // Ignore
    }
  }

  playMessageReceived() {
    if (!this.enabled) return;
    const ctx = this.getContext();
    if (!ctx) return;
    try {
      const now = ctx.currentTime;
      const notes = [523.25, 659.25, 783.99];
      notes.forEach((freq, i) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = "sine";
        osc.frequency.setValueAtTime(freq, now + i * 0.05);
        gain.gain.setValueAtTime(0.12, now + i * 0.05);
        gain.gain.exponentialRampToValueAtTime(0.001, now + i * 0.05 + 0.15);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now + i * 0.05);
        osc.stop(now + i * 0.05 + 0.16);
      });
    } catch {
      // Ignore
    }
  }
}

export const sounds = new SoundManager();

// Clean text for speech: strips markdown, brackets and ensures ONLY the real response is spoken
export function prepareSpeechText(text: string): string {
  if (!text || typeof text !== "string") return "";
  return text
    .replace(/^["']|["']$/g, "")
    .replace(
      /^(fale\s+em\s+tom|fale\s+com\s+sotaque|fale|tom|sotaque|instrução|resposta)\s*[^:]*:\s*/i,
      ""
    )
    .replace(/[*_#`~[\]()]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

// --------------------------------------------------------------------------
// UNIFIED ROMULOKO BRAZILIAN VOICE ENGINE (SINGLETON)
// --------------------------------------------------------------------------

class RomulokoVoiceEngine {
  private activeAudio: HTMLAudioElement | null = null;
  private activeUtterance: SpeechSynthesisUtterance | null = null;
  private cachedVoice: SpeechSynthesisVoice | null = null;
  private clientAudioCache = new Map<string, string>(); // cleanText -> blobUrl
  private isPreloading: boolean = false;

  constructor() {
    if (typeof window !== "undefined") {
      this.initVoiceDiscovery();
    }
  }

  // Preload and resolve Brazilian Portuguese voices once
  private initVoiceDiscovery() {
    if (typeof window === "undefined" || !("speechSynthesis" in window)) return;

    const findVoice = () => {
      const voices = window.speechSynthesis.getVoices();
      if (!voices || voices.length === 0) return;

      // Filter STRICTLY for Brazilian voices, eliminating ANY European Portuguese
      const brVoices = voices.filter((v) => {
        const lang = (v.lang || "").toLowerCase().replace("_", "-");
        const name = (v.name || "").toLowerCase();

        // STRICT BLACKLIST: Never allow Portugal voices
        if (
          lang === "pt-pt" ||
          lang.startsWith("pt-pt") ||
          name.includes("portugal") ||
          name.includes("joana") ||
          name.includes("catarina") ||
          name.includes("helia") ||
          name.includes("amalia")
        ) {
          return false;
        }

        return (
          lang === "pt-br" ||
          lang.startsWith("pt-br") ||
          name.includes("brasil") ||
          name.includes("brazil") ||
          name.includes("luciana") ||
          name.includes("felipe") ||
          name.includes("daniel") ||
          name.includes("francisca") ||
          name.includes("heloisa") ||
          name.includes("maria")
        );
      });

      if (brVoices.length > 0) {
        // Preferred order: expressive Google/Microsoft/Natural Brazilian male or female
        const preferred =
          brVoices.find(
            (v) =>
              v.name.includes("Google") ||
              v.name.includes("Natural") ||
              v.name.includes("Daniel") ||
              v.name.includes("Felipe")
          ) || brVoices[0];

        this.cachedVoice = preferred;
      }
    };

    findVoice();
    window.speechSynthesis.onvoiceschanged = findVoice;
  }

  // Pre-fetch server audio in background when a response arrives
  public async prefetch(text: string): Promise<void> {
    const cleanText = prepareSpeechText(text);
    if (!cleanText || this.clientAudioCache.has(cleanText) || this.isPreloading) {
      return;
    }

    try {
      this.isPreloading = true;
      const res = await fetch("/api/tts", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text: cleanText }),
      });

      if (res.ok) {
        const blob = await res.blob();
        const url = URL.createObjectURL(blob);
        this.clientAudioCache.set(cleanText, url);
      }
    } catch {
      // Ignore background prefetch errors
    } finally {
      this.isPreloading = false;
    }
  }

  // Speak via Web Speech API strictly configured in pt-BR
  private speakViaWebSpeech(
    cleanText: string,
    onStart?: () => void,
    onEnd?: () => void
  ): boolean {
    if (typeof window === "undefined" || !("speechSynthesis" in window)) {
      if (onEnd) onEnd();
      return false;
    }

    try {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(cleanText);

      // PERSISTENT UNIFIED SETTINGS
      utterance.lang = "pt-BR";
      utterance.rate = 1.15; // Natural, fast Brazilian comedic timing
      utterance.pitch = 1.0;

      if (this.cachedVoice) {
        utterance.voice = this.cachedVoice;
      }

      this.activeUtterance = utterance;

      if (onStart) onStart();

      utterance.onstart = () => {
        if (onStart) onStart();
      };

      utterance.onend = () => {
        this.activeUtterance = null;
        if (onEnd) onEnd();
      };

      utterance.onerror = () => {
        this.activeUtterance = null;
        if (onEnd) onEnd();
      };

      window.speechSynthesis.speak(utterance);
      return true;
    } catch {
      this.activeUtterance = null;
      if (onEnd) onEnd();
      return false;
    }
  }

  // Unified playback entry point for ALL messages (1st, 2nd, 3rd, 5th, etc.)
  public async speak(
    text: string,
    onStart?: () => void,
    onEnd?: () => void
  ): Promise<void> {
    this.stop();

    const cleanText = prepareSpeechText(text);
    if (!cleanText) {
      if (onEnd) onEnd();
      return;
    }

    // 1. If audio is already cached in memory, play it instantly
    const cachedUrl = this.clientAudioCache.get(cleanText);
    if (cachedUrl) {
      this.playAudioUrl(cachedUrl, onStart, onEnd);
      return;
    }

    // 2. Otherwise request from /api/tts (which has server cache and multi-model fallback)
    try {
      if (onStart) onStart();

      const response = await fetch("/api/tts", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text: cleanText }),
      });

      if (!response.ok) {
        throw new Error("TTS endpoint indisponível");
      }

      const blob = await response.blob();
      const url = URL.createObjectURL(blob);
      this.clientAudioCache.set(cleanText, url);

      this.playAudioUrl(url, onStart, onEnd);
    } catch {
      // 3. Fallback to unified Brazilian Web Speech synthesis with locked pt-BR settings
      this.speakViaWebSpeech(cleanText, onStart, onEnd);
    }
  }

  private playAudioUrl(
    url: string,
    onStart?: () => void,
    onEnd?: () => void
  ) {
    try {
      const audio = new Audio(url);
      this.activeAudio = audio;
      audio.playbackRate = 1.08;

      if (onStart) onStart();

      audio.onended = () => {
        this.activeAudio = null;
        if (onEnd) onEnd();
      };

      audio.onerror = () => {
        this.activeAudio = null;
        if (onEnd) onEnd();
      };

      audio.play().catch(() => {
        this.activeAudio = null;
        if (onEnd) onEnd();
      });
    } catch {
      this.activeAudio = null;
      if (onEnd) onEnd();
    }
  }

  // Stop playback instantly
  public stop(): void {
    if (this.activeAudio) {
      this.activeAudio.pause();
      this.activeAudio = null;
    }
    if (typeof window !== "undefined" && "speechSynthesis" in window) {
      window.speechSynthesis.cancel();
      this.activeUtterance = null;
    }
  }
}

export const romulokoVoice = new RomulokoVoiceEngine();

export const playRomulokoVoice = (
  text: string,
  onStart?: () => void,
  onEnd?: () => void
) => romulokoVoice.speak(text, onStart, onEnd);

export const stopRomulokoVoice = () => romulokoVoice.stop();

export const prefetchRomulokoVoice = (text: string) =>
  romulokoVoice.prefetch(text);

// Backward-compat aliases
export const speakResendeText = playRomulokoVoice;
export const stopSpeaking = stopRomulokoVoice;
