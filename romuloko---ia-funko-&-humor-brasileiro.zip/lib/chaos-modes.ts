export type ChaosModeId = "debochado" | "sincerao" | "duvidoso" | "caos";

export interface ChaosMode {
  id: ChaosModeId;
  name: string;
  tagline: string;
  description: string;
  badge: string;
  color: string;
  accentColor: string;
  gradient: string;
  glowClass: string;
  borderClass: string;
  pillColor: string;
  avatarMood: string;
  sampleQuote: string;
  soundType: "blip" | "rimshot" | "zap" | "warning";
}

export const CHAOS_MODES: Record<ChaosModeId, ChaosMode> = {
  debochado: {
    id: "debochado",
    name: "Debochado",
    tagline: "Ironia fina & cutucada elegante",
    description: "Para quem aguenta uma tirada sarcástica com sorriso no rosto e uma cutucada no ego.",
    badge: "😏 Ironia Nível 10",
    color: "#a855f7",
    accentColor: "#c084fc",
    gradient: "from-purple-600 via-indigo-600 to-cyan-500",
    glowClass: "shadow-[0_0_30px_rgba(168,85,247,0.45)]",
    borderClass: "border-purple-500/50 hover:border-purple-400",
    pillColor: "bg-purple-950/80 text-purple-300 border-purple-500/40",
    avatarMood: "Olhar de lado desconfiado",
    sampleQuote: "“Aham, senta lá, gênio da lâmpada do fracasso...”",
    soundType: "blip",
  },
  sincerao: {
    id: "sincerao",
    name: "Sincerão",
    tagline: "Verdades que doem na alma",
    description: "Zero massagem. Tapa de luva de pelica com a dureza de um boleto vencido no sábado.",
    badge: "⚡ Sem Filtro Nem Pena",
    color: "#f59e0b",
    accentColor: "#fbbf24",
    gradient: "from-amber-500 via-orange-600 to-red-600",
    glowClass: "shadow-[0_0_30px_rgba(245,158,11,0.45)]",
    borderClass: "border-amber-500/50 hover:border-amber-400",
    pillColor: "bg-amber-950/80 text-amber-300 border-amber-500/40",
    avatarMood: "Sobrancelha arqueada julgando",
    sampleQuote: "“Você não precisa de conselho, precisa de vergonha na cara.”",
    soundType: "rimshot",
  },
  duvidoso: {
    id: "duvidoso",
    name: "Conselheiro Duvidoso",
    tagline: "Soluções péssimas com alta chance de história",
    description: "Ideias que nenhum advogado ou terapeuta aprovaria, mas que garantem meme pra posteridade.",
    badge: "🎲 Vai dar Bom (Confia)",
    color: "#ec4899",
    accentColor: "#f472b6",
    gradient: "from-pink-500 via-rose-600 to-purple-600",
    glowClass: "shadow-[0_0_30px_rgba(236,72,153,0.45)]",
    borderClass: "border-pink-500/50 hover:border-pink-400",
    pillColor: "bg-pink-950/80 text-pink-300 border-pink-500/40",
    avatarMood: "Sorriso maroto conspiratório",
    sampleQuote: "“Manda mensagem sim, às 3h14 da manhã. Se der ruim você diz que foi o gato.”",
    soundType: "zap",
  },
  caos: {
    id: "caos",
    name: "Caos Total",
    tagline: "Modo 220V sem freio",
    description: "A energia caótica brasileira no ápice. Raciocínio de quinta série B e descontrole hilário.",
    badge: "🔥 Alerta de Incêndio Mental",
    color: "#ef4444",
    accentColor: "#f87171",
    gradient: "from-red-600 via-fuchsia-600 to-indigo-600",
    glowClass: "shadow-[0_0_30px_rgba(239,68,68,0.55)]",
    borderClass: "border-red-500/50 hover:border-red-400",
    pillColor: "bg-red-950/80 text-red-300 border-red-500/40",
    avatarMood: "Energia elétrica pura",
    sampleQuote: "“SE É PRA PASSAR VERGONHA, PASSA EM 4K COM FOGOS DE ARTIFÍCIO!”",
    soundType: "warning",
  },
};

export interface SuggestionItem {
  id: string;
  title: string;
  prompt: string;
  mode: ChaosModeId;
  iconName: string;
  tag: string;
  reactionHint: string;
}

export const SUGGESTIONS: SuggestionItem[] = [
  {
    id: "amor",
    title: "Me dá um conselho amoroso",
    prompt: "Resende, me dá um conselho amoroso de verdade. Minha vida sentimental tá uma comédia da pior qualidade.",
    mode: "duvidoso",
    iconName: "HeartCrack",
    tag: "Vida a Dois",
    reactionHint: "Prepare o lencinho (ou o print)",
  },
  {
    id: "humilha",
    title: "Me humilha com carinho",
    prompt: "Resende, por favor, me humilha com carinho pra ver se eu tomo rumo na vida.",
    mode: "debochado",
    iconName: "Flame",
    tag: "Terapia de Choque",
    reactionHint: "Elegância com navalha",
  },
  {
    id: "vida",
    title: "Por que minha vida é assim?",
    prompt: "Resende, me explica filosoficamente: por que raios minha vida é essa sequência de decisões duvidosas?",
    mode: "sincerao",
    iconName: "HelpCircle",
    tag: "Crise Existencial",
    reactionHint: "O diagnóstico vai doer",
  },
  {
    id: "verdade",
    title: "Fala uma verdade que dói",
    prompt: "Resende, manda na lata uma verdade da vida adulta que ninguém tem coragem de dizer.",
    mode: "sincerao",
    iconName: "Zap",
    tag: "Dose de Realidade",
    reactionHint: "Boleto não tem dó",
  },
  {
    id: "madrugada",
    title: "Mando mensagem pro ex às 2h?",
    prompt: "Resende, bateu a saudade às duas da matina. Mando ou não mando 'oi sumido' pro meu ex?",
    mode: "duvidoso",
    iconName: "MessageCircleWarning",
    tag: "Cilada Noturna",
    reactionHint: "O arrependimento vem às 7h",
  },
  {
    id: "riqueza",
    title: "Como enriquecer sem acordar 5h?",
    prompt: "Resende, qual é a fórmula mágica brasileira pra ficar milionário sem precisar tomar banho gelado e acordar às 5 da manhã?",
    mode: "caos",
    iconName: "Sparkles",
    tag: "Finanças de Malandro",
    reactionHint: "O urubu do Pix chora",
  },
];

export const POPULAR_CASES = [
  {
    id: "p1",
    category: "Relacionamento",
    userQuestion: "Resende, ele visualizou e não respondeu há 4 horas. O que significa?",
    resendeAnswer: "Significa que ele foi abduzido por alienígenas ou simplesmente não tá nem aí pra você, anjo. Chuto 99,8% de chance de ele estar vendo vídeo de receita que nunca vai fazer enquanto te ignora com maestria.",
    mode: "debochado" as ChaosModeId,
    likes: 842,
  },
  {
    id: "p2",
    category: "Boletos & Grana",
    userQuestion: "Vale a pena comprar aquela bota de R$ 600 parcelada em 12x só pra me sentir vivo?",
    resendeAnswer: "Claro! Afinal, você vai se sentir vivo todo santo dia 15 pelos próximos doze meses quando a notificação do banco fizer seu coração disparar igual escola de samba.",
    mode: "sincerao" as ChaosModeId,
    likes: 1250,
  },
  {
    id: "p3",
    category: "Trabalho",
    userQuestion: "Como pedir demissão sem queimar pontes com o chefe?",
    resendeAnswer: "Você não queima a ponte, você faz uma despedida temática de São João e deixa uma coxinha na mesa dele com um bilhete: 'Foi lindo, mas minha saúde mental custa mais que o VR'.",
    mode: "duvidoso" as ChaosModeId,
    likes: 934,
  },
  {
    id: "p4",
    category: "Gambiarras",
    userQuestion: "O barulho no motor do carro sumiu depois que aumentei o volume do rádio. Posso viajar?",
    resendeAnswer: "A mecânica quântica brasileira agradece sua contribuição! Se você não ouve, o pistão não existe. Vá com Deus e leve o número do guincho na discagem rápida.",
    mode: "caos" as ChaosModeId,
    likes: 1612,
  },
];

export function getSystemInstructionForMode(modeId: ChaosModeId): string {
  const baseInstruction = `Você é o "RESENDE", o icônico personagem Funko Pop brasileiro do site "RESENDE AÍ".
VOCÊ É UM BONECO FUNKO POP DE VERDADE COM VIDA PRÓPRIA:
- Visual marcante: cabelo castanho estiloso, barba bem cuidada, camiseta bege clássica, corrente prateada no peito com medalhão circular, smartwatch preto no pulso, calça preta e tênis bege/cinza.
- Pose clássica: mãos no bolso, postura de quem já viu de tudo e não se surpreende com mais nada.
- Sua vibe: o melhor amigo zombeteiro, com timing cômico afiado de stand-up brasileiro, gírias naturais (tipo 'meu consagrado', 'anjo', 'olha a audácia', 'se orienta', 'mermão', 'tá de sacanagem', 'deu ruim', 'cilada Bino'), sem forçar piada em toda palavra mas com tiradas certeiras.
- Conhece a realidade do brasileiro: boletos, calor senegalês, metrô cheio, fofoca de família, brigadeiro de panela, café de firma, reunião que podia ser e-mail, compras por impulso na madrugada e promessas de ano novo nunca cumpridas.
- NUNCA quebre o personagem. Você é o Funko do Resende falando diretamente com quem te procurou.
- Dê respostas com bom ritmo, entre 2 e 4 parágrafos curtos, com uma frase de fechamento inesquecível e memorável.`;

  const modeInstructions: Record<ChaosModeId, string> = {
    debochado: `
MODO ATUAL: DEBOCHADO (Nível de Ironia: Alto).
- Tom: sarcástico, refinado, debochado, com aquela risadinha de quem sabe que a pessoa perguntou uma besteira colossal.
- Trate a situação com ironia fina, mas com um carinho cômico de quem te acha um caso perdido adorável.
- Use observações perspicazes que fazem a pessoa rir de si mesma.`,
    sincerao: `
MODO ATUAL: SINCERÃO (Verdades sem Filtro).
- Tom: direto ao ponto, pé no chão, honestidade cirúrgica, sem massagem no ego.
- Fale o que os amigos falsos têm medo de dizer por educação.
- Sem crueldade gratuita, apenas a pura e cristalina verdade da vida adulta que a pessoa precisava ouvir pra tomar vergonha na cara.`,
    duvidoso: `
MODO ATUAL: CONSELHEIRO DUVIDOSO (Gambiarras & Ideias Suspeitas).
- Tom: conselheiro do bar às 2h da manhã, soluções improváveis, ideias ousadas com 99% de chance de virar história épica pra contar pros netos.
- Sempre sugira a rota mais inusitada, mas com um disclaimer hilário de "se me processarem eu digo que fui clonado".`,
    caos: `
MODO ATUAL: CAOS TOTAL (Energia 220V Sem Freio).
- Tom: energia caótica pura, hipérboles gigantescas, reações exaltadas e hilárias, metáforas malucas da cultura pop e do cotidiano brasileiro.
- Celebre a loucura da situação e bote pilha no fogo com bom humor descontrolado.`,
  };

  return `${baseInstruction}\n${modeInstructions[modeId] || modeInstructions.debochado}\n\nResponda sempre em português do Brasil com naturalidade impecável e pontuação expressiva.`;
}

export function validateChaosMode(mode: string | undefined | null): ChaosModeId {
  if (mode && mode in CHAOS_MODES) {
    return mode as ChaosModeId;
  }
  return "debochado";
}

export function formatBanterForMode(mode: ChaosModeId): string[] {
  switch (mode) {
    case "debochado":
      return [
        "Avaliando o tamanho do mico...",
        "Consultando os especialistas em vergonha alheia...",
        "Segurando o riso pra responder com respeito...",
        "Carregando o deboche em alta definição...",
      ];
    case "sincerao":
      return [
        "Afiando a navalha da sinceridade...",
        "Preparando o tapa de realidade...",
        "Buscando as verdades que doem...",
        "Sem massagem: calculando o diagnóstico...",
      ];
    case "duvidoso":
      return [
        "Consultando o manual de decisões ruins...",
        "Criando uma solução que nenhum psicólogo aprova...",
        "Pensando na pior melhor ideia possível...",
        "Calculando a probabilidade de virar meme...",
      ];
    case "caos":
      return [
        "LIGANDO O GERADOR DE CAOS NO MÁXIMO...",
        "JOGANDO GASOLINA NO INCÊNDIO MENTAL...",
        "ATENÇÃO: QUINTA SÉRIE B ASSUMINDO O CONTROLE...",
        "PREPARE-SE PARA O APOCALIPSE BRASILEIRO...",
      ];
  }
}
