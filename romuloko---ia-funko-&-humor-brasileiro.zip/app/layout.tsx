import type { Metadata } from "next";
import { Space_Grotesk, Plus_Jakarta_Sans } from "next/font/google";
import "./globals.css";

const spaceGrotesk = Space_Grotesk({
  subsets: ["latin"],
  variable: "--font-space-grotesk",
  display: "swap",
});

const plusJakartaSans = Plus_Jakarta_Sans({
  subsets: ["latin"],
  variable: "--font-jakarta-sans",
  display: "swap",
});

export const metadata: Metadata = {
  title: "ROMULOKO - IA Funko & Humor Brasileiro",
  description:
    "O universo de humor brasileiro comandado pelo Funko Pop Romuloko. Humor ácido, sarcasmo inteligente, deboche na medida certa e respostas sob medida.",
  openGraph: {
    title: "ROMULOKO - IA Funko & Humor Brasileiro",
    description:
      "O universo de humor brasileiro comandado pelo Funko Pop Romuloko. Humor ácido, sarcasmo inteligente, deboche na medida certa e respostas sob medida.",
    type: "website",
    locale: "pt_BR",
  },
  twitter: {
    card: "summary_large_image",
    title: "ROMULOKO - IA Funko & Humor Brasileiro",
    description:
      "O universo de humor brasileiro comandado pelo Funko Pop Romuloko. Humor ácido, sarcasmo inteligente, deboche na medida certa e respostas sob medida.",
  },
};

export const viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  viewportFit: "cover",
  themeColor: "#080410",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="pt-BR" className={`dark scroll-smooth ${spaceGrotesk.variable} ${plusJakartaSans.variable}`}>
      <body
        suppressHydrationWarning
        className="min-h-screen bg-[#080410] text-slate-100 antialiased selection:bg-purple-600 selection:text-white"
        style={{ fontFamily: "var(--font-jakarta-sans), system-ui, sans-serif" }}
      >
        {children}
      </body>
    </html>
  );
}
