import Link from "next/link";

export default function NotFound() {
  return (
    <div className="min-h-screen bg-[#080410] text-slate-100 flex flex-col items-center justify-center p-6 text-center">
      <div className="w-16 h-16 rounded-2xl bg-purple-950/80 border border-purple-500/40 flex items-center justify-center text-3xl font-black text-pink-400 mb-4 shadow-[0_0_30px_rgba(236,72,153,0.3)]">
        404
      </div>
      <h1 className="text-2xl sm:text-3xl font-extrabold text-white font-['Space_Grotesk'] mb-2">
        Página não encontrada, meu consagrado!
      </h1>
      <p className="text-sm text-slate-400 max-w-md mb-6">
        O Romuloko procurou essa rota no multiverso e só achou poeira e boleto atrasado.
      </p>
      <Link
        href="/"
        className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-pink-600 text-white font-bold text-sm shadow-lg shadow-purple-600/30 hover:scale-105 transition-all"
      >
        Voltar pro Romuloko
      </Link>
    </div>
  );
}
