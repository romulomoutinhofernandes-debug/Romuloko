import { NextRequest, NextResponse } from "next/server";
import { ai } from "@/lib/gemini";
import { getRomulokoSystemInstruction } from "@/lib/romuloko";

export interface ChatMessage {
  role: "user" | "model";
  content: string;
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { messages }: { messages: ChatMessage[] } = body;

    if (!messages || !Array.isArray(messages) || messages.length === 0) {
      return NextResponse.json(
        { error: "Nenhuma mensagem enviada pro Romuloko." },
        { status: 400 }
      );
    }

    const systemInstruction = getRomulokoSystemInstruction();

    // Format contents for @google/genai
    const recentMessages = messages.slice(-8).map((m) => ({
      role: m.role === "user" ? "user" : "model",
      parts: [{ text: m.content }],
    }));

    if (recentMessages.length > 0 && recentMessages[0].role !== "user") {
      recentMessages.shift();
    }

    // Candidate models with fast fallback
    const candidateModels = [
      "gemini-3.1-flash-lite",
      "gemini-3.8-flash",
      "gemini-flash-latest",
    ];
    let lastError: unknown = null;
    let replyText = "";

    for (const modelName of candidateModels) {
      try {
        const response = await ai.models.generateContent({
          model: modelName,
          contents: recentMessages,
          config: {
            systemInstruction,
            temperature: 1.0,
            topP: 0.95,
            maxOutputTokens: 180,
          },
        });

        if (response.text) {
          replyText = response.text.trim();
          break;
        }
      } catch (err) {
        lastError = err;
        console.warn(`Model ${modelName} returned error, trying next candidate...`);
      }
    }

    if (!replyText) {
      throw lastError || new Error("Não foi possível obter resposta de nenhum modelo.");
    }

    return NextResponse.json({
      reply: replyText,
    });
  } catch (error: unknown) {
    console.error("Erro na API do Romuloko:", error);
    const errorMessage = error instanceof Error ? error.message : "Erro desconhecido";

    return NextResponse.json({
      reply:
        "Coé, o multiverso deu uma engasgada aqui. Respira fundo e manda de novo que o Romuloko resolve.",
      warning: "Instabilidade temporária de rede.",
      details: process.env.NODE_ENV === "development" ? errorMessage : undefined,
    });
  }
}
