import { NextRequest, NextResponse } from "next/server";
import { ai } from "@/lib/gemini";

// In-memory audio cache so identical or repeated texts never re-query Gemini API quota
const audioCache = new Map<string, Buffer>();

// Helper to strip any markdown, emojis, or accidental prefixes so ONLY the response is spoken
function cleanSpokenText(raw: string): string {
  if (!raw || typeof raw !== "string") return "";
  return raw
    .replace(/^["']|["']$/g, "") // surrounding quotes
    .replace(
      /^(fale\s+em\s+tom|fale\s+com\s+sotaque|fale|tom|sotaque|instrução|resposta)\s*[^:]*:\s*/i,
      ""
    )
    .replace(/[*_#`~[\]()]/g, "") // markdown symbols
    .replace(/\s+/g, " ")
    .trim();
}

export async function POST(req: NextRequest) {
  try {
    const { text } = await req.json();

    const cleanText = cleanSpokenText(text).slice(0, 300);

    if (!cleanText) {
      return NextResponse.json(
        { error: "Texto vazio ou inválido" },
        { status: 400 }
      );
    }

    // 1. Check in-memory server cache first (instant return, zero quota consumption)
    const cachedBuffer = audioCache.get(cleanText);
    if (cachedBuffer) {
      return new NextResponse(new Uint8Array(cachedBuffer), {
        status: 200,
        headers: {
          "Content-Type": "audio/wav",
          "Content-Length": cachedBuffer.length.toString(),
          "Cache-Control": "public, max-age=86400",
        },
      });
    }

    // 2. Try TTS models with fallback to avoid 429 rate limits
    const candidateModels = ["gemini-3.8-flash-tts", "gemini-3.8-flash-lite-tts"];
    let audioBuffer: Buffer | null = null;
    let lastError: unknown = null;

    for (const model of candidateModels) {
      try {
        const response = await ai.models.generateContent({
          model,
          contents: [{ role: "user", parts: [{ text: cleanText }] }],
          config: {
            responseModalities: ["AUDIO"],
            speechConfig: {
              voiceConfig: {
                prebuiltVoiceConfig: { voiceName: "Puck" },
              },
            },
          },
        });

        const base64Audio =
          response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;

        if (base64Audio) {
          audioBuffer = Buffer.from(base64Audio, "base64");
          // Save to server cache (keep cache size bounded to last 100 entries)
          if (audioCache.size > 100) {
            const firstKey = audioCache.keys().next().value;
            if (firstKey) audioCache.delete(firstKey);
          }
          audioCache.set(cleanText, audioBuffer);
          break;
        }
      } catch (err) {
        lastError = err;
        console.warn(`Modelo ${model} indisponível para TTS, tentando próximo...`);
      }
    }

    if (!audioBuffer) {
      throw lastError || new Error("Nenhum modelo de TTS gerou áudio.");
    }

    return new NextResponse(new Uint8Array(audioBuffer), {
      status: 200,
      headers: {
        "Content-Type": "audio/wav",
        "Content-Length": audioBuffer.length.toString(),
        "Cache-Control": "public, max-age=86400",
      },
    });
  } catch (err: unknown) {
    const errorMessage = err instanceof Error ? err.message : "Erro desconhecido";
    console.warn("TTS Gemini indisponível, acionando fallback do cliente:", errorMessage);

    return NextResponse.json(
      { error: "TTS fallback para cliente", fallbackToClient: true },
      { status: 503 }
    );
  }
}
