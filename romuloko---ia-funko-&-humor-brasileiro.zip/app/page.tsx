"use client";

import React, { useRef, useState } from "react";
import Navbar from "@/components/Navbar";
import RomulokoChat, { RomulokoChatHandle } from "@/components/RomulokoChat";
import Footer from "@/components/Footer";
import { RomulokoMood } from "@/lib/romuloko";

export default function HomePage() {
  const chatRef = useRef<RomulokoChatHandle>(null);
  const [mood, setMood] = useState<RomulokoMood>("normal");

  const handleClearChat = () => {
    chatRef.current?.clearChat();
  };

  return (
    <div className="h-dvh max-h-dvh bg-[#080410] text-slate-100 flex flex-col justify-between selection:bg-purple-600 selection:text-white overflow-hidden">
      {/* Top Header with Romuloko brand, compact reactive avatar and sound toggle */}
      <Navbar onClearChat={handleClearChat} mood={mood} />

      {/* Main Single-Screen Content: Chat occupies virtually all useful screen space */}
      <main className="flex-1 flex flex-col min-h-0 overflow-hidden">
        <RomulokoChat ref={chatRef} onMoodChange={setMood} />
      </main>

      {/* Compact Clean Footer (hidden on mobile to preserve 100% of screen for chat, visible on desktop) */}
      <div className="hidden sm:block shrink-0">
        <Footer />
      </div>
    </div>
  );
}
