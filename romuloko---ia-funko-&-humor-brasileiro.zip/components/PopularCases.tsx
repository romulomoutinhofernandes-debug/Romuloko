"use client";

import React, { useState } from "react";
import Image from "next/image";
import { MessageCircle, ThumbsUp, ArrowRight, Sparkles, Send } from "lucide-react";
import { POPULAR_CASES, ChaosModeId, CHAOS_MODES } from "@/lib/chaos-modes";
import { sounds } from "@/lib/audio-effects";

interface PopularCasesProps {
  onTestQuestion: (question: string, mode: ChaosModeId) => void;
}

export default function PopularCases({ onTestQuestion }: PopularCasesProps) {
  const [activeCategory, setActiveCategory] = useState<string>("Todos");
  const [likes, setLikes] = useState<Record<string, number>>(() =>
    POPULAR_CASES.reduce((acc, curr) => ({ ...acc, [curr.id]: curr.likes }), {})
  );
  const [liked, setLiked] = useState<Record<string, boolean>>({});

  const categories = ["Todos", "Relacionamento", "Boletos & Grana", "Trabalho", "Gambiarras"];

  const filteredCases =
    activeCategory === "Todos"
      ? POPULAR_CASES
      : POPULAR_CASES.filter((c) => c.category === activeCategory);

  const handleLike = (id: string) => {
    sounds.playBlip();
    if (liked[id]) {
      setLikes((prev) => ({ ...prev, [id]: prev[id] - 1 }));
      setLiked((prev) => ({ ...prev, [id]: false }));
    } else {
      setLikes((prev) => ({ ...prev, [id]: prev[id] + 1 }));
      setLiked((prev) => ({ ...prev, [id]: true }));
    }
  };

  return (
    <section id="mural-de-micos" className="py-20 relative bg-[#080413]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-10">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-pink-950/80 border border-pink-500/30 text-pink-300 text-xs font-semibold mb-3">
            <Sparkles className="w-3.5 h-3.5 text-pink-400" />
            <span>ARQUIVO CONFIDENCIAL DO RESENDE</span>
          </div>
          <h2 className="text-3xl sm:text-5xl font-extrabold text-white tracking-tight font-['Space_Grotesk'] mb-3">
            Mural de Micos &{" "}
            <span className="bg-clip-text text-transparent bg-gradient-to-r from-pink-400 via-purple-400 to-cyan-300">
              Casos Reais
            </span>
          </h2>
          <p className="text-slate-300 text-sm sm:text-base">
            Veja as maiores furadas enviadas pelos internautas e como o Resende
            resolveu com pura elegância e zero piedade.
          </p>
        </div>

        {/* Category Filter Pills */}
        <div className="flex items-center justify-center gap-2 flex-wrap mb-10">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => {
                sounds.playBlip();
                setActiveCategory(cat);
              }}
              className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all ${
                activeCategory === cat
                  ? "bg-gradient-to-r from-purple-600 to-pink-600 text-white shadow-lg shadow-purple-600/30 scale-105"
                  : "bg-[#130928] text-slate-400 hover:text-white hover:bg-[#1a0d36] border border-purple-950"
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Cases Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {filteredCases.map((item) => {
            const mode = CHAOS_MODES[item.mode];
            const isLiked = liked[item.id];
            return (
              <div
                key={item.id}
                className="rounded-3xl bg-[#110724]/90 border border-purple-900/40 p-6 sm:p-7 shadow-xl hover:border-purple-600/60 transition-all flex flex-col justify-between"
              >
                <div>
                  {/* Category & Mode Badge */}
                  <div className="flex items-center justify-between mb-4">
                    <span className="px-3 py-1 rounded-full text-xs font-semibold bg-purple-950 text-purple-300 border border-purple-800/40">
                      {item.category}
                    </span>
                    <span className={`text-[11px] font-bold px-2.5 py-0.5 rounded-full border ${mode.pillColor}`}>
                      {mode.name}
                    </span>
                  </div>

                  {/* User Question */}
                  <div className="mb-4">
                    <div className="text-xs uppercase font-bold text-slate-400 tracking-wider mb-1">
                      A Dúvida do Cidadão:
                    </div>
                    <p className="text-base sm:text-lg font-bold text-white font-['Space_Grotesk'] leading-snug">
                      “{item.userQuestion}”
                    </p>
                  </div>

                  {/* Resende Answer */}
                  <div className="p-4 rounded-2xl bg-[#180a34] border border-purple-800/40 relative mb-4">
                    <div className="flex items-center gap-2 mb-2">
                      <div className="w-6 h-6 rounded-lg bg-purple-900 overflow-hidden relative">
                        <Image
                          src="/assets/aistudio/romulo_funko_9b7f39ed.png"
                          alt="Resende"
                          width={24}
                          height={24}
                          className="object-cover object-top scale-125"
                          referrerPolicy="no-referrer"
                        />
                      </div>
                      <span className="text-xs font-bold text-cyan-300 font-['Space_Grotesk']">
                        Veredito do Resende:
                      </span>
                    </div>
                    <p className="text-sm text-slate-200 leading-relaxed italic">
                      “{item.resendeAnswer}”
                    </p>
                  </div>
                </div>

                {/* Card Actions */}
                <div className="pt-4 border-t border-purple-950 flex items-center justify-between">
                  <button
                    onClick={() => handleLike(item.id)}
                    aria-label="Curtir essa resposta"
                    className={`flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 rounded-xl border transition-all ${
                      isLiked
                        ? "bg-pink-950/80 border-pink-500/50 text-pink-300 shadow-sm"
                        : "bg-purple-950/40 border-purple-900/40 text-slate-400 hover:text-white"
                    }`}
                  >
                    <ThumbsUp className={`w-3.5 h-3.5 ${isLiked ? "fill-pink-400 text-pink-400" : ""}`} />
                    <span>{likes[item.id]}</span>
                  </button>

                  <button
                    onClick={() => {
                      sounds.playBlip();
                      onTestQuestion(item.userQuestion, item.mode);
                    }}
                    className="flex items-center gap-1.5 text-xs font-bold text-cyan-400 hover:text-cyan-300 px-3 py-1.5 rounded-xl bg-cyan-950/40 border border-cyan-800/40 hover:bg-cyan-900/40 transition-all"
                  >
                    <span>Mandar no Chat</span>
                    <Send className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
