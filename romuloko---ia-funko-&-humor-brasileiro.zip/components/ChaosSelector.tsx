"use client";

import React from "react";
import confetti from "canvas-confetti";
import { Flame, ShieldAlert, Sparkles, Zap, Check, ArrowRight } from "lucide-react";
import { ChaosModeId, CHAOS_MODES } from "@/lib/chaos-modes";
import { sounds } from "@/lib/audio-effects";

interface ChaosSelectorProps {
  currentMode: ChaosModeId;
  onSelectMode: (mode: ChaosModeId) => void;
  onScrollToChat: () => void;
}

export default function ChaosSelector({
  currentMode,
  onSelectMode,
  onScrollToChat,
}: ChaosSelectorProps) {
  const modes = Object.values(CHAOS_MODES);

  const handleModeClick = (modeId: ChaosModeId) => {
    onSelectMode(modeId);
    if (modeId === "debochado") sounds.playBlip();
    else if (modeId === "sincerao") sounds.playRimshot();
    else if (modeId === "duvidoso") sounds.playZap();
    else if (modeId === "caos") {
      sounds.playChaosWarning();
      // Mini confetti celebration for Caos Total
      try {
        confetti({
          particleCount: 50,
          spread: 60,
          origin: { y: 0.6 },
          colors: ["#ef4444", "#a855f7", "#ec4899", "#06b6d4"],
        });
      } catch {
        // Ignore in environments where canvas is not supported
      }
    }
  };

  const getModeIcon = (modeId: ChaosModeId) => {
    switch (modeId) {
      case "debochado":
        return <Sparkles className="w-5 h-5 text-purple-400" />;
      case "sincerao":
        return <Zap className="w-5 h-5 text-amber-400" />;
      case "duvidoso":
        return <ShieldAlert className="w-5 h-5 text-pink-400" />;
      case "caos":
        return <Flame className="w-5 h-5 text-red-500 animate-pulse" />;
    }
  };

  return (
    <section id="niveis-de-caos" className="py-20 relative bg-[#090514]">
      {/* Background radial highlight */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[400px] bg-purple-900/10 rounded-full blur-[160px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-purple-950/80 border border-purple-500/30 text-purple-300 text-xs font-semibold mb-3">
            <Flame className="w-3.5 h-3.5 text-amber-400" />
            <span>CALIBRE O HUMOR DO RESENDE</span>
          </div>
          <h2 className="text-3xl sm:text-5xl font-extrabold text-white tracking-tight font-['Space_Grotesk'] mb-4">
            Escolha seu{" "}
            <span className="bg-clip-text text-transparent bg-gradient-to-r from-purple-400 via-pink-400 to-amber-300">
              Nível de Caos
            </span>
          </h2>
          <p className="text-slate-300 text-base sm:text-lg">
            O Resende tem 4 frequências de resposta. Escolha com sabedoria ou
            arque com as consequências morais do seu ego.
          </p>
        </div>

        {/* 4 Mode Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {modes.map((mode) => {
            const isSelected = currentMode === mode.id;
            return (
              <button
                key={mode.id}
                type="button"
                onClick={() => handleModeClick(mode.id)}
                aria-label={`Selecionar modo de humor ${mode.name}`}
                className={`text-left group relative rounded-2xl p-6 cursor-pointer transition-all duration-300 flex flex-col justify-between border ${
                  isSelected
                    ? `bg-[#190d33] ${mode.borderClass} ${mode.glowClass} scale-[1.03]`
                    : "bg-[#110822]/80 border-purple-950/70 hover:border-purple-600/40 hover:bg-[#150a2c]"
                }`}
              >
                {/* Selected Status Corner Badge */}
                {isSelected && (
                  <div className="absolute -top-3 right-4 px-2.5 py-0.5 rounded-full bg-gradient-to-r from-purple-600 to-cyan-500 text-[10px] font-bold text-white shadow-lg flex items-center gap-1">
                    <Check className="w-3 h-3" />
                    <span>ATIVO NO CHAT</span>
                  </div>
                )}

                <div>
                  {/* Icon & Badge Header */}
                  <div className="flex items-center justify-between mb-4">
                    <div className="w-10 h-10 rounded-xl bg-purple-950/90 border border-purple-500/30 flex items-center justify-center">
                      {getModeIcon(mode.id)}
                    </div>
                    <span className="text-[11px] font-bold text-slate-400">
                      {mode.badge}
                    </span>
                  </div>

                  {/* Title & Tagline */}
                  <h3 className="text-xl font-bold text-white mb-1 font-['Space_Grotesk']">
                    {mode.name}
                  </h3>
                  <div className="text-xs font-semibold text-cyan-300 mb-3">
                    {mode.tagline}
                  </div>

                  {/* Description */}
                  <p className="text-sm text-slate-300 leading-relaxed mb-4">
                    {mode.description}
                  </p>
                </div>

                {/* Sample Quote & Action */}
                <div>
                  <div className="p-3 rounded-xl bg-[#0b0518]/80 border border-purple-950 text-xs italic text-slate-300 mb-4">
                    {mode.sampleQuote}
                  </div>

                  <div className="flex items-center justify-between pt-2 border-t border-purple-900/40">
                    <span className="text-[11px] font-medium text-slate-400">
                      {isSelected ? "Modo selecionado" : "Clique para ativar"}
                    </span>
                    <span className="text-xs font-bold text-purple-300 group-hover:text-cyan-300 flex items-center gap-1 transition-colors">
                      <span>Testar</span>
                      <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                    </span>
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </section>
  );
}
