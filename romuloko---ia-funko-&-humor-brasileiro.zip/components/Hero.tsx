"use client";

import React, { useState } from "react";
import Image from "next/image";
import { Send, Sparkles, Flame, Zap, ShieldAlert, ArrowDown } from "lucide-react";
import { ChaosModeId, CHAOS_MODES } from "@/lib/chaos-modes";
import { sounds } from "@/lib/audio-effects";

interface HeroProps {
  currentMode: ChaosModeId;
  onQuickAsk: (question: string) => void;
  onScrollToChat: () => void;
  onScrollToCaos: () => void;
}

export default function Hero({
  currentMode,
  onQuickAsk,
  onScrollToChat,
  onScrollToCaos,
}: HeroProps) {
  const [quickInput, setQuickInput] = useState("");
  const mode = CHAOS_MODES[currentMode];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!quickInput.trim()) return;
    sounds.playBlip();
    onQuickAsk(quickInput.trim());
    setQuickInput("");
  };

  return (
    <section
      id="hero"
      className="relative min-h-screen pt-28 pb-16 flex items-center justify-center overflow-hidden bg-[#080410]"
    >
      {/* Background ambient lighting effects */}
      <div className="absolute inset-0 bg-cyber-grid opacity-30 pointer-events-none" />
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[650px] h-[650px] bg-purple-600/20 rounded-full blur-[140px] pointer-events-none" />
      <div className="absolute top-1/3 left-1/4 w-[400px] h-[400px] bg-cyan-600/15 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute top-1/2 right-1/4 w-[450px] h-[450px] bg-pink-600/15 rounded-full blur-[130px] pointer-events-none" />

      {/* Main Container */}
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
          
          {/* Left Column: Headlines, Slogan & Quick Question input */}
          <div className="lg:col-span-7 flex flex-col items-center lg:items-start text-center lg:text-left pt-4 lg:pt-0">
            {/* Top Online Pill */}
            <div className="inline-flex flex-wrap items-center justify-center gap-2 px-3 sm:px-3.5 py-1 sm:py-1.5 rounded-full bg-purple-950/70 border border-purple-500/40 text-purple-300 text-[11px] sm:text-xs font-semibold mb-6 shadow-lg shadow-purple-900/20">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping inline-block shrink-0" />
              <span>CONSULTORIA DE HUMOR • 100% IA NACIONAL</span>
              <span className="px-1.5 py-0.5 rounded bg-pink-500/20 text-pink-300 text-[10px] font-bold uppercase tracking-wider">
                {mode.name}
              </span>
            </div>

            {/* Main Headline */}
            <h1 className="text-4xl sm:text-6xl xl:text-7xl font-extrabold tracking-tight text-white leading-[1.08] font-['Space_Grotesk'] mb-6">
              MANDA A PERGUNTA.{" "}
              <span className="bg-clip-text text-transparent bg-gradient-to-r from-purple-400 via-pink-400 to-cyan-300 drop-shadow-[0_0_35px_rgba(168,85,247,0.4)]">
                EU NÃO PROMETO JUÍZO.
              </span>
            </h1>

            {/* Subtitle */}
            <p className="text-base sm:text-xl text-slate-300 max-w-2xl font-normal leading-relaxed mb-8">
              O único consultor Funko Pop do multiverso que te escuta com as mãos
              no bolso, julga suas decisões com carinho duvidoso e resolve sua vida
              na base do deboche elegante.
            </p>

            {/* Quick Question Input Bar */}
            <form
              onSubmit={handleSubmit}
              className="w-full max-w-xl relative group mb-8"
            >
              <div className="relative flex items-center rounded-2xl bg-[#120a26]/90 border border-purple-500/40 p-1.5 sm:p-2 shadow-2xl shadow-purple-950/50 backdrop-blur-md focus-within:border-cyan-400 focus-within:shadow-[0_0_30px_rgba(6,182,212,0.35)] transition-all">
                <input
                  type="text"
                  value={quickInput}
                  onChange={(e) => setQuickInput(e.target.value)}
                  placeholder="Ex: Devo parcelar minha vida em 12x no cartão?..."
                  aria-label="Digite sua pergunta para o Resende"
                  className="w-full bg-transparent px-4 py-2.5 text-sm sm:text-base text-white placeholder-slate-400 focus:outline-none"
                />
                <button
                  type="submit"
                  aria-label="Enviar pergunta para o Resende"
                  className="shrink-0 flex items-center gap-2 px-5 py-2.5 sm:py-3 rounded-xl bg-gradient-to-r from-purple-600 via-pink-600 to-cyan-500 hover:from-purple-500 hover:to-cyan-400 text-white font-bold text-xs sm:text-sm shadow-md shadow-purple-600/30 transition-all hover:scale-105 active:scale-95"
                >
                  <span>Mandar</span>
                  <Send className="w-4 h-4" />
                </button>
              </div>
              <div className="flex items-center justify-between px-3 pt-2 text-[11px] text-slate-400">
                <span>Dica: Escolha seu nível de caos abaixo</span>
                <button
                  type="button"
                  onClick={onScrollToCaos}
                  className="text-cyan-400 hover:underline flex items-center gap-1 font-medium"
                >
                  <Flame className="w-3.5 h-3.5 text-amber-400" />
                  Ver 4 personalidades
                </button>
              </div>
            </form>

            {/* Comedy Stats Badges */}
            <div className="grid grid-cols-3 gap-3 sm:gap-4 w-full max-w-xl">
              <div className="p-3 sm:p-3.5 rounded-xl bg-[#140b2a]/60 border border-purple-900/40 backdrop-blur-sm">
                <div className="text-xl sm:text-2xl font-black text-cyan-400 font-['Space_Grotesk']">
                  +15.000
                </div>
                <div className="text-[11px] sm:text-xs text-slate-400 mt-0.5">
                  Conselhos duvidosos
                </div>
              </div>
              <div className="p-3 sm:p-3.5 rounded-xl bg-[#140b2a]/60 border border-purple-900/40 backdrop-blur-sm">
                <div className="text-xl sm:text-2xl font-black text-amber-400 font-['Space_Grotesk']">
                  R$ 0,00
                </div>
                <div className="text-[11px] sm:text-xs text-slate-400 mt-0.5">
                  Boletos pagos pelo boneco
                </div>
              </div>
              <div className="p-3 sm:p-3.5 rounded-xl bg-[#140b2a]/60 border border-purple-900/40 backdrop-blur-sm">
                <div className="text-xl sm:text-2xl font-black text-pink-400 font-['Space_Grotesk']">
                  100%
                </div>
                <div className="text-[11px] sm:text-xs text-slate-400 mt-0.5">
                  Sinceridade sem anestesia
                </div>
              </div>
            </div>

          </div>

          {/* Right Column: Prominent Funko Pop Stage / Showcase */}
          <div className="lg:col-span-5 flex flex-col items-center justify-center relative">
            {/* Holographic Glowing Backdrop Rings */}
            <div className="relative w-full max-w-[380px] sm:max-w-[440px] aspect-[4/5] flex items-center justify-center">
              
              {/* Backlight Aura Glow */}
              <div className="absolute inset-0 bg-gradient-to-t from-purple-700/30 via-pink-600/20 to-cyan-500/20 rounded-full blur-3xl animate-pulse-ring" />
              
              {/* Neon Cyber Pedestal Stage */}
              <div className="absolute -bottom-4 w-[280px] sm:w-[320px] h-[50px] rounded-full bg-gradient-to-r from-purple-600/80 via-cyan-400/80 to-pink-500/80 blur-md opacity-70 transform rotate-[-3deg]" />
              <div className="absolute -bottom-2 w-[240px] sm:w-[280px] h-[28px] rounded-full bg-[#1b0d36] border-2 border-cyan-400/70 shadow-[0_0_35px_rgba(6,182,212,0.8)]" />
              <div className="absolute -bottom-1 w-[180px] sm:w-[220px] h-[16px] rounded-full bg-purple-500/40 blur-[4px]" />

              {/* Floating stickers / tags */}
              <div className="absolute top-6 -left-3 sm:-left-6 z-20 px-3 py-1.5 rounded-xl bg-purple-950/90 border border-purple-400/50 shadow-xl shadow-purple-950 text-xs font-bold text-purple-200 flex items-center gap-1.5 transform -rotate-6 animate-float-subtle">
                <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
                <span>Camiseta Bege & Corrente</span>
              </div>

              <div className="absolute top-28 -right-2 sm:-right-4 z-20 px-3 py-1.5 rounded-xl bg-pink-950/90 border border-pink-400/50 shadow-xl shadow-pink-950 text-xs font-bold text-pink-200 flex items-center gap-1.5 transform rotate-6">
                <Zap className="w-3.5 h-3.5 text-amber-400" />
                <span>Juízo Zero Garantido</span>
              </div>

              <div className="absolute bottom-16 -left-2 sm:-left-4 z-20 px-3 py-1.5 rounded-xl bg-cyan-950/90 border border-cyan-400/50 shadow-xl shadow-cyan-950 text-xs font-bold text-cyan-200 flex items-center gap-1.5 transform rotate-3">
                <ShieldAlert className="w-3.5 h-3.5 text-cyan-300" />
                <span>Mãos no Bolso & Postura</span>
              </div>

              {/* The Funko Pop Character Image */}
              <div className="relative z-10 w-full h-full flex items-end justify-center filter drop-shadow-[0_20px_35px_rgba(0,0,0,0.85)] group cursor-pointer transition-transform duration-500 hover:scale-105"
                onClick={onScrollToChat}
                title="Clique para bater um papo com o Resende!"
              >
                <Image
                  src="/assets/aistudio/romulo_funko_9b7f39ed.png"
                  alt="Funko Pop do Resende - Personagem principal de humor brasileiro"
                  width={420}
                  height={620}
                  priority
                  className="object-contain max-h-[520px] sm:max-h-[580px] drop-shadow-[0_10px_25px_rgba(168,85,247,0.35)]"
                  style={{ width: "auto", height: "auto" }}
                  referrerPolicy="no-referrer"
                />
              </div>

            </div>

            {/* Character Mood Status Bar */}
            <div className="mt-4 flex items-center gap-2 px-4 py-2 rounded-full bg-[#170c32]/80 border border-purple-500/30 text-xs text-slate-300 shadow-lg">
              <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
              <span>Humor do Resende: <strong>{mode.tagline}</strong></span>
            </div>

          </div>

        </div>

        {/* Scroll Indicator */}
        <div className="mt-14 flex justify-center">
          <button
            onClick={onScrollToCaos}
            aria-label="Rolar para a seção de níveis de caos"
            className="flex flex-col items-center gap-1.5 text-xs text-purple-300/60 hover:text-purple-300 transition-colors animate-bounce focus:outline-none"
          >
            <span>Descubra os Níveis de Caos</span>
            <ArrowDown className="w-4 h-4" />
          </button>
        </div>
      </div>
    </section>
  );
}
