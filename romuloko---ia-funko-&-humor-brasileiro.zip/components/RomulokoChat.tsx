"use client";

import React, { useState, useRef, useEffect, useCallback } from "react";
import Image from "next/image";
import {
  Send,
  Volume2,
  VolumeX,
  Copy,
  Check,
  RotateCcw,
  Sparkles,
  Zap,
  Loader2,
  User,
} from "lucide-react";
import {
  ROMULOKO_SUGGESTIONS,
  ROMULOKO_THINKING_QUOTES,
  RomulokoMood,
  detectMoodFromContext,
} from "@/lib/romuloko";
import {
  sounds,
  playRomulokoVoice,
  stopRomulokoVoice,
  prefetchRomulokoVoice,
} from "@/lib/audio-effects";

export interface ChatMessage {
  id: string;
  role: "user" | "model";
  content: string;
  timestamp: string;
}

export interface RomulokoChatHandle {
  clearChat: () => void;
}

interface RomulokoChatProps {
  onMoodChange?: (mood: RomulokoMood) => void;
}

const RomulokoChat = React.forwardRef<RomulokoChatHandle, RomulokoChatProps>(
  ({ onMoodChange }, ref) => {
    const [messages, setMessages] = useState<ChatMessage[]>([
      {
        id: "welcome-1",
        role: "model",
        content:
          "Coé, meu consagrado! Romuloko na área com as mãos no bolso e juízo zero. Manda a bronca que eu resolvo na lata.",
        timestamp: "Agora",
      },
    ]);
    const [inputText, setInputText] = useState("");
    const [isLoading, setIsLoading] = useState(false);
    const [thinkingQuote, setThinkingQuote] = useState("");
    const [speakingId, setSpeakingId] = useState<string | null>(null);
    const [copiedId, setCopiedId] = useState<string | null>(null);
    const [reactions, setReactions] = useState<Record<string, string>>({});
    const [currentMood, setCurrentMood] = useState<RomulokoMood>("normal");

    const chatContainerRef = useRef<HTMLDivElement>(null);
    const textareaRef = useRef<HTMLTextAreaElement>(null);
    const isFirstRender = useRef(true);

    // Update mood and notify parent
    const updateMood = useCallback(
      (mood: RomulokoMood) => {
        setCurrentMood(mood);
        if (onMoodChange) onMoodChange(mood);
      },
      [onMoodChange]
    );

    // Warm up voice and pre-cache initial welcome message audio
    useEffect(() => {
      prefetchRomulokoVoice(
        "Coé, meu consagrado! Romuloko na área com as mãos no bolso e juízo zero. Manda a bronca que eu resolvo na lata."
      );
    }, []);

    // Auto-scroll chat container to bottom
    const scrollToBottom = useCallback(() => {
      if (chatContainerRef.current) {
        chatContainerRef.current.scrollTo({
          top: chatContainerRef.current.scrollHeight,
          behavior: isFirstRender.current ? "instant" : "smooth",
        });
      }
    }, []);

    useEffect(() => {
      if (isFirstRender.current) {
        isFirstRender.current = false;
        return;
      }
      scrollToBottom();
    }, [messages, isLoading, thinkingQuote, scrollToBottom]);

    // Cycle thinking quotes and maintain 'pensando' mood during generation
    useEffect(() => {
      if (!isLoading) {
        return;
      }
      updateMood("pensando");
      let index = 0;
      setThinkingQuote(ROMULOKO_THINKING_QUOTES[0]);

      const interval = setInterval(() => {
        index = (index + 1) % ROMULOKO_THINKING_QUOTES.length;
        setThinkingQuote(ROMULOKO_THINKING_QUOTES[index]);
      }, 2200);

      return () => clearInterval(interval);
    }, [isLoading, updateMood]);

    // Send message
    const handleSendMessage = useCallback(
      async (textToSend?: string) => {
        const text = textToSend || inputText;
        if (!text.trim() || isLoading) return;

        sounds.playBlip();

        // Detect initial context mood
        const detected = detectMoodFromContext(text, false);
        updateMood(detected !== "normal" ? detected : "pensando");

        const userMsg: ChatMessage = {
          id: `user-${Date.now()}`,
          role: "user",
          content: text.trim(),
          timestamp: new Date().toLocaleTimeString("pt-BR", {
            hour: "2-digit",
            minute: "2-digit",
          }),
        };

        const nextHistory = [...messages, userMsg];
        setMessages(nextHistory);
        setInputText("");
        setIsLoading(true);

        try {
          const payload = nextHistory.map((m) => ({
            role: m.role,
            content: m.content,
          }));

          const res = await fetch("/api/chat", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ messages: payload }),
          });

          const data = await res.json();
          sounds.playMessageReceived();

          const modelReply =
            data.reply ||
            "Olha, sem palavras pro tamanho da sua audácia. Pergunta de novo aí!";

          const modelMsg: ChatMessage = {
            id: `model-${Date.now()}`,
            role: "model",
            content: modelReply,
            timestamp: new Date().toLocaleTimeString("pt-BR", {
              hour: "2-digit",
              minute: "2-digit",
            }),
          };

          setMessages((prev) => [...prev, modelMsg]);
          prefetchRomulokoVoice(modelReply);

          // Set mood based on answer content
          const replyMood = detectMoodFromContext(modelReply, false);
          updateMood(replyMood !== "normal" ? replyMood : "debochando");
        } catch (err) {
          console.error(err);
          setMessages((prev) => [
            ...prev,
            {
              id: `error-${Date.now()}`,
              role: "model",
              content:
                "Deu uma travada no multiverso do Romuloko. Mas não se iluda: você ainda precisa tomar vergonha na cara. Manda de novo aí!",
              timestamp: new Date().toLocaleTimeString("pt-BR", {
                hour: "2-digit",
                minute: "2-digit",
              }),
            },
          ]);
          updateMood("surpreso");
        } finally {
          setIsLoading(false);
        }
      },
      [inputText, isLoading, messages, updateMood]
    );

    const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
      if (e.key === "Enter" && !e.shiftKey) {
        e.preventDefault();
        handleSendMessage();
      }
    };

    const toggleSpeak = (id: string, text: string) => {
      if (speakingId === id) {
        stopRomulokoVoice();
        setSpeakingId(null);
        updateMood("normal");
      } else {
        setSpeakingId(id);
        updateMood("debochando");
        playRomulokoVoice(
          text,
          () => setSpeakingId(id),
          () => {
            setSpeakingId(null);
            updateMood("normal");
          }
        );
      }
    };

    const handleCopy = (id: string, text: string) => {
      navigator.clipboard.writeText(text);
      setCopiedId(id);
      sounds.playBlip();
      setTimeout(() => setCopiedId(null), 2000);
    };

    const handleClear = useCallback(() => {
      stopRomulokoVoice();
      sounds.playBlip();
      updateMood("normal");
      setMessages([
        {
          id: `reset-${Date.now()}`,
          role: "model",
          content:
            "Memória zerada, mermão! Manda a próxima bronca antes que minha paciência vença.",
          timestamp: new Date().toLocaleTimeString("pt-BR", {
            hour: "2-digit",
            minute: "2-digit",
          }),
        },
      ]);
    }, [updateMood]);

    const handleReaction = (msgId: string, emoji: string) => {
      sounds.playBlip();
      setReactions((prev) => ({ ...prev, [msgId]: emoji }));
      const reactionMood = detectMoodFromContext("", false, emoji);
      updateMood(reactionMood);
    };

    React.useImperativeHandle(
      ref,
      () => ({
        clearChat: handleClear,
      }),
      [handleClear]
    );

    return (
      <div className="w-full max-w-7xl mx-auto px-0 sm:px-4 lg:px-8 py-0 sm:py-4 flex-1 flex flex-col h-full overflow-hidden">
        
        {/* Main Side-by-Side on Desktop / Full Screen Chat on Mobile */}
        <div className="flex-1 flex flex-col lg:grid lg:grid-cols-12 gap-0 sm:gap-5 items-stretch h-full overflow-hidden">
          
          {/* Desktop Left Column: Funko Romuloko Spotlight Showcase (HIDDEN ON MOBILE to save 100% space) */}
          <div className="hidden lg:flex lg:col-span-4 xl:col-span-3 flex-col justify-between rounded-3xl bg-gradient-to-b from-[#140a28]/95 via-[#0e061e]/95 to-[#160b2e]/95 border border-purple-800/40 p-5 shadow-2xl shadow-purple-950/40 backdrop-blur-xl relative overflow-hidden shrink-0">
            
            {/* Ambient Lighting */}
            <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[220px] h-[220px] bg-purple-600/20 rounded-full blur-[80px] pointer-events-none" />
            <div className="absolute bottom-1/4 right-1/4 w-[180px] h-[180px] bg-cyan-600/15 rounded-full blur-[70px] pointer-events-none" />

            {/* Top Status */}
            <div className="relative z-10 flex items-center justify-between">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-purple-950/80 border border-purple-500/40 text-purple-300 text-xs font-semibold shadow-inner">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                <span>ROMULOKO</span>
              </div>
              <span className="text-[11px] font-bold text-cyan-300 tracking-wider uppercase">
                100% Sincero
              </span>
            </div>

            {/* Funko Showcase on Cyber Pedestal */}
            <div className="relative z-10 flex-1 flex flex-col items-center justify-center my-2">
              <div className="relative w-full max-w-[220px] aspect-[4/5] flex items-end justify-center">
                
                {/* Cyber Pedestal Stage */}
                <div className="absolute -bottom-2 w-[180px] h-[30px] rounded-full bg-gradient-to-r from-purple-600 via-cyan-400 to-pink-500 blur-md opacity-75" />
                <div className="absolute -bottom-0.5 w-[150px] h-[18px] rounded-full bg-[#1b0d36] border-2 border-cyan-400/80 shadow-[0_0_20px_rgba(6,182,212,0.7)]" />

                {/* Floating stickers */}
                <div className="absolute top-2 -left-2 z-20 px-2 py-0.5 rounded-xl bg-purple-950/95 border border-purple-400/50 shadow-lg text-[10px] font-bold text-purple-200 flex items-center gap-1 transform -rotate-6 animate-float-subtle">
                  <Sparkles className="w-3 h-3 text-cyan-400" />
                  <span>Camiseta Bege</span>
                </div>

                <div className="absolute top-16 -right-2 z-20 px-2 py-0.5 rounded-xl bg-pink-950/95 border border-pink-400/50 shadow-lg text-[10px] font-bold text-pink-200 flex items-center gap-1 transform rotate-6">
                  <Zap className="w-3 h-3 text-amber-400" />
                  <span>Mãos no Bolso</span>
                </div>

                {/* Funko Pop Image */}
                <div className="relative z-10 w-full h-full flex items-end justify-center group cursor-pointer transition-transform duration-300 hover:scale-105">
                  <Image
                    src="/assets/aistudio/romulo_funko_9b7f39ed.png"
                    alt="Funko Pop Romuloko"
                    width={260}
                    height={390}
                    priority
                    className={`object-contain max-h-[280px] drop-shadow-[0_15px_30px_rgba(0,0,0,0.85)] ${
                      isLoading ? "scale-105 animate-pulse" : ""
                    }`}
                    style={{ width: "auto", height: "auto" }}
                    referrerPolicy="no-referrer"
                  />
                </div>
              </div>

              <div className="text-center mt-2">
                <h2 className="text-sm font-extrabold text-white font-['Space_Grotesk'] leading-snug">
                  “MANDA A PERGUNTA. EU NÃO PROMETO JUÍZO.”
                </h2>
                <p className="text-[10px] text-slate-300 mt-0.5 max-w-[200px]">
                  Deboche refinado, conselhos sem filtro e sabedoria das ruas.
                </p>
              </div>
            </div>

            {/* Desktop Suggestions Under Funko */}
            <div className="relative z-10 pt-3 border-t border-purple-900/40">
              <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1.5 flex items-center justify-between">
                <span>Puxar assunto:</span>
                <span className="text-cyan-400 text-[10px]">1 clique</span>
              </div>
              <div className="space-y-1.5">
                {ROMULOKO_SUGGESTIONS.slice(0, 3).map((chip) => (
                  <button
                    key={chip.id}
                    onClick={() => handleSendMessage(chip.prompt)}
                    disabled={isLoading}
                    className="w-full px-3 py-2 rounded-xl bg-[#0e061e] border border-purple-900/60 hover:border-cyan-400/70 hover:bg-[#160a2e] text-slate-300 hover:text-white text-xs font-semibold text-left transition-all disabled:opacity-50 truncate flex items-center justify-between group active:scale-98"
                  >
                    <span className="truncate">{chip.label}</span>
                    <Sparkles className="w-3 h-3 text-cyan-400 opacity-60 group-hover:opacity-100 shrink-0 ml-1" />
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Chat Console: Takes 100% of mobile viewport area & 8-9 cols on desktop */}
          <div className="lg:col-span-8 xl:col-span-9 flex flex-col rounded-none sm:rounded-3xl bg-[#0e061e]/98 border-0 sm:border sm:border-purple-800/40 shadow-2xl shadow-purple-950/40 backdrop-blur-xl overflow-hidden h-full flex-1">
            
            {/* Desktop-only inner chat room banner (on mobile the sticky header avatar handles this to save height) */}
            <div className="hidden sm:flex px-4 sm:px-6 py-3 bg-gradient-to-r from-[#150a2e]/90 via-[#100724]/90 to-[#180c33]/90 border-b border-purple-900/40 items-center justify-between shrink-0">
              <div className="flex items-center gap-3">
                <div className="relative w-9 h-9 rounded-xl bg-gradient-to-tr from-purple-600 to-cyan-400 p-[1.5px]">
                  <div className="w-full h-full bg-[#120726] rounded-[10px] overflow-hidden">
                    <Image
                      src="/assets/aistudio/romulo_funko_9b7f39ed.png"
                      alt="Romuloko"
                      width={36}
                      height={36}
                      priority
                      className="object-cover object-top scale-125 translate-y-1"
                      style={{ width: "auto", height: "auto" }}
                      referrerPolicy="no-referrer"
                    />
                  </div>
                  <span className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 bg-emerald-400 rounded-full border border-[#0f0721]" />
                </div>

                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="font-bold text-white text-sm sm:text-base font-['Space_Grotesk']">
                      Romuloko
                    </h3>
                    <span className="px-2 py-0.2 rounded-full bg-emerald-950/80 text-emerald-300 border border-emerald-500/30 text-[10px] font-bold">
                      Online
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400">
                    Pronto para responder qualquer assunto ou mandar a real
                  </p>
                </div>
              </div>

              <button
                onClick={handleClear}
                aria-label="Reiniciar conversa"
                className="px-3 py-1.5 rounded-xl bg-purple-950/70 border border-purple-700/40 text-purple-300 hover:text-white hover:bg-purple-900/70 transition-all text-xs font-semibold flex items-center gap-1.5 active:scale-95"
                title="Limpar conversa"
              >
                <RotateCcw className="w-3.5 h-3.5 text-pink-400" />
                <span>Limpar</span>
              </button>
            </div>

            {/* Independent Scrollable Messages Area */}
            <div
              ref={chatContainerRef}
              className="flex-1 overflow-y-auto px-3 sm:px-6 py-3 sm:py-4 space-y-3 sm:space-y-4 overscroll-contain"
            >
              {messages.map((msg) => {
                const isUser = msg.role === "user";
                const isSpeakingThis = speakingId === msg.id;

                return (
                  <div
                    key={msg.id}
                    className={`flex items-start gap-2 sm:gap-3 transition-opacity duration-300 ${
                      isUser ? "flex-row-reverse" : "flex-row"
                    }`}
                  >
                    {/* Avatar beside bubble */}
                    {!isUser ? (
                      <div className="shrink-0 w-7 h-7 sm:w-8 sm:h-8 rounded-xl bg-[#1d0d3b] border border-purple-500/40 overflow-hidden relative shadow-md mt-0.5">
                        <Image
                          src="/assets/aistudio/romulo_funko_9b7f39ed.png"
                          alt="Romuloko"
                          width={32}
                          height={32}
                          className="object-cover object-top scale-125 translate-y-0.5"
                          style={{ width: "auto", height: "auto" }}
                          referrerPolicy="no-referrer"
                        />
                      </div>
                    ) : (
                      <div className="shrink-0 w-7 h-7 sm:w-8 sm:h-8 rounded-xl bg-gradient-to-tr from-cyan-600 to-indigo-600 flex items-center justify-center text-white text-[11px] font-bold shadow-md mt-0.5">
                        <User className="w-3.5 h-3.5" />
                      </div>
                    )}

                    {/* Message Bubble */}
                    <div
                      className={`max-w-[88%] sm:max-w-[82%] rounded-2xl p-3.5 sm:p-5 relative transition-all ${
                        isUser
                          ? "bg-gradient-to-r from-purple-700 via-fuchsia-700 to-indigo-700 text-white shadow-lg shadow-purple-950/40 rounded-tr-sm border border-purple-500/30"
                          : "bg-gradient-to-br from-[#180b33]/95 via-[#120726]/95 to-[#0b0417]/95 border border-purple-700/40 text-slate-100 shadow-xl shadow-purple-950/30 rounded-tl-sm backdrop-blur-md"
                      }`}
                    >
                      {/* Message Content */}
                      <div className="text-sm sm:text-base leading-relaxed whitespace-pre-line font-normal selection:bg-cyan-500 selection:text-black break-words">
                        {msg.content}
                      </div>

                      {/* Controls on Romuloko's Message */}
                      {!isUser && (
                        <div className="mt-2.5 pt-2.5 border-t border-purple-900/40 flex items-center justify-between text-xs text-slate-400 gap-2 flex-wrap">
                          {/* Audio Speak & Copy with comfortable touch targets */}
                          <div className="flex items-center gap-1.5 sm:gap-2">
                            
                            {/* Audio Player Button with Animated Soundwave Equalizer */}
                            <button
                              onClick={() => toggleSpeak(msg.id, msg.content)}
                              aria-label={
                                isSpeakingThis
                                  ? "Parar áudio do Romuloko"
                                  : "Ouvir resposta em português brasileiro"
                              }
                              className={`min-h-[34px] px-2.5 py-1.5 rounded-xl border transition-all flex items-center gap-1.5 active:scale-95 ${
                                isSpeakingThis
                                  ? "bg-cyan-500 text-white border-cyan-300 shadow-[0_0_12px_rgba(6,182,212,0.6)] animate-pulse"
                                  : "bg-purple-950/70 border-purple-700/40 text-purple-200 hover:text-white hover:bg-purple-900/70 hover:border-cyan-400/50"
                              }`}
                              title={
                                isSpeakingThis
                                  ? "Clique para parar o áudio"
                                  : "Ouvir com a voz brasileira do Romuloko"
                              }
                            >
                              {isSpeakingThis ? (
                                <>
                                  <VolumeX className="w-3.5 h-3.5 text-white shrink-0" />
                                  <span className="flex items-end gap-0.5 h-2.5 shrink-0">
                                    <span className="w-0.5 bg-white rounded-full animate-bounce h-2" />
                                    <span className="w-0.5 bg-white rounded-full animate-bounce h-2.5 delay-100" />
                                    <span className="w-0.5 bg-white rounded-full animate-bounce h-1.5 delay-200" />
                                  </span>
                                  <span className="text-[10px] sm:text-[11px] font-bold">Ouvindo</span>
                                </>
                              ) : (
                                <>
                                  <Volume2 className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                                  <span className="text-[10px] sm:text-[11px] font-semibold">
                                    Ouvir
                                  </span>
                                </>
                              )}
                            </button>

                            {/* Copy Button */}
                            <button
                              onClick={() => handleCopy(msg.id, msg.content)}
                              aria-label="Copiar resposta do Romuloko"
                              className="min-h-[34px] min-w-[34px] p-1.5 rounded-xl bg-purple-950/70 border border-purple-700/40 text-purple-200 hover:text-white hover:bg-purple-900/70 transition-all flex items-center justify-center active:scale-95"
                              title="Copiar texto"
                            >
                              {copiedId === msg.id ? (
                                <Check className="w-3.5 h-3.5 text-emerald-400" />
                              ) : (
                                <Copy className="w-3.5 h-3.5" />
                              )}
                            </button>
                          </div>

                          {/* Reaction Emojis */}
                          <div className="flex items-center gap-1">
                            {["😂", "💀", "🔥", "👏"].map((emoji) => {
                              const isReacted = reactions[msg.id] === emoji;
                              return (
                                <button
                                  key={emoji}
                                  onClick={() => handleReaction(msg.id, emoji)}
                                  className={`min-w-[30px] min-h-[30px] p-1 rounded-lg transition-transform active:scale-125 flex items-center justify-center ${
                                    isReacted
                                      ? "bg-purple-800 text-sm shadow-sm"
                                      : "opacity-65 hover:opacity-100"
                                  }`}
                                  title={`Reagir com ${emoji}`}
                                >
                                  {emoji}
                                </button>
                              );
                            })}
                          </div>
                        </div>
                      )}

                      {/* Timestamp */}
                      <span className="block text-[10px] text-slate-400/60 mt-1 text-right select-none">
                        {msg.timestamp}
                      </span>
                    </div>
                  </div>
                );
              })}

              {/* Thinking Animated Bubble */}
              {isLoading && (
                <div className="flex items-start gap-2 sm:gap-3 animate-in fade-in duration-300">
                  <div className="shrink-0 w-7 h-7 sm:w-8 sm:h-8 rounded-xl bg-[#1d0d3b] border border-cyan-400/60 overflow-hidden relative shadow-lg shadow-cyan-500/20 animate-pulse mt-0.5">
                    <Image
                      src="/assets/aistudio/romulo_funko_9b7f39ed.png"
                      alt="Romuloko Pensando"
                      width={32}
                      height={32}
                      className="object-cover object-top scale-125 translate-y-0.5"
                      style={{ width: "auto", height: "auto" }}
                      referrerPolicy="no-referrer"
                    />
                  </div>
                  <div className="rounded-2xl p-3 sm:p-4 bg-gradient-to-r from-[#1c0c3c] to-[#120726] border border-cyan-400/50 text-cyan-200 text-xs sm:text-sm shadow-xl flex items-center gap-2.5">
                    <Loader2 className="w-4 h-4 animate-spin text-cyan-400 shrink-0" />
                    <span className="font-medium italic">
                      {thinkingQuote || "Romuloko preparando a resposta..."}
                    </span>
                  </div>
                </div>
              )}
            </div>

            {/* Quick Starter Chips Bar (Compact horizontal scroll) */}
            <div className="px-2.5 sm:px-4 py-1.5 bg-[#120726]/85 border-t border-purple-900/30 flex items-center gap-1.5 overflow-x-auto no-scrollbar shrink-0">
              <span className="text-[10px] font-bold text-slate-400 shrink-0 hidden sm:inline">
                Sugestões:
              </span>
              {ROMULOKO_SUGGESTIONS.map((chip) => (
                <button
                  key={chip.id}
                  onClick={() => handleSendMessage(chip.prompt)}
                  disabled={isLoading}
                  className="shrink-0 px-2.5 py-1 rounded-full bg-purple-950/70 border border-purple-800/40 text-purple-200 text-[11px] sm:text-xs hover:border-cyan-400 hover:text-white transition-all disabled:opacity-50 active:scale-95 whitespace-nowrap"
                >
                  {chip.label}
                </button>
              ))}
            </div>

            {/* Fixed Bottom Message Input Bar (Adapted for Mobile Safe Areas & Virtual Keyboards) */}
            <div className="p-2 sm:p-3.5 bg-gradient-to-t from-[#0a0417] via-[#0e0620] to-[#14092e] border-t border-purple-900/50 shrink-0 pb-[max(0.6rem,env(safe-area-inset-bottom))]">
              <div className="flex items-center gap-1.5 sm:gap-2 bg-[#0c0419] rounded-2xl border border-purple-700/50 p-1.5 sm:p-2 focus-within:border-cyan-400 focus-within:shadow-[0_0_20px_rgba(6,182,212,0.35)] transition-all">
                <textarea
                  ref={textareaRef}
                  value={inputText}
                  onChange={(e) => setInputText(e.target.value)}
                  onKeyDown={handleKeyDown}
                  placeholder="Mande sua dúvida pro Romuloko..."
                  rows={1}
                  aria-label="Mensagem para o Romuloko"
                  className="w-full bg-transparent px-2.5 sm:px-3 py-1.5 text-sm sm:text-base text-white placeholder-slate-500 focus:outline-none resize-none max-h-24 sm:max-h-32"
                />

                {/* Send Button */}
                <button
                  type="button"
                  onClick={() => handleSendMessage()}
                  disabled={!inputText.trim() || isLoading}
                  aria-label="Enviar mensagem para o Romuloko"
                  className="shrink-0 min-w-[40px] min-h-[40px] px-3 sm:px-4 py-2 rounded-xl bg-gradient-to-r from-purple-600 via-pink-600 to-cyan-500 text-white font-bold text-xs sm:text-sm shadow-md shadow-purple-600/30 transition-all hover:scale-105 active:scale-95 disabled:opacity-40 disabled:hover:scale-100 flex items-center justify-center gap-1.5"
                >
                  <span className="hidden sm:inline">Enviar</span>
                  <Send className="w-4 h-4" />
                </button>
              </div>

              <div className="flex items-center justify-between px-2 pt-1 text-[9px] sm:text-[10px] text-slate-400">
                <span className="hidden sm:inline">Enter para enviar • Shift + Enter para quebrar linha</span>
                <span className="sm:hidden">Romuloko 100% sem filtro</span>
                <span>IA Gemini 3.1 • Voz pt-BR</span>
              </div>
            </div>

          </div>

        </div>
      </div>
    );
  }
);

RomulokoChat.displayName = "RomulokoChat";

export default RomulokoChat;
