"use client";

import React, { useState, useRef, useEffect, useCallback } from "react";
import Image from "next/image";
import {
  Send,
  Volume2,
  VolumeX,
  Copy,
  Check,
  RotateCcw,
  Bot,
  User,
  Loader2,
} from "lucide-react";
import {
  ChaosModeId,
  CHAOS_MODES,
  formatBanterForMode,
} from "@/lib/chaos-modes";
import { sounds, speakResendeText, stopSpeaking } from "@/lib/audio-effects";

export interface Message {
  id: string;
  role: "user" | "model";
  content: string;
  mode?: ChaosModeId;
  timestamp: string;
}

interface ChatLoungeProps {
  currentMode: ChaosModeId;
  onSelectMode: (mode: ChaosModeId) => void;
  initialQuestion?: string;
  onQuestionConsumed?: () => void;
}

export default function ChatLounge({
  currentMode,
  onSelectMode,
  initialQuestion,
  onQuestionConsumed,
}: ChatLoungeProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "welcome-1",
      role: "model",
      content:
        "E aí, meu consagrado! Sou o Resende em versão Funko Pop. Tô com as mãos no bolso e com a paciência calibrada no limite. O que você aprontou dessa vez pra vir me pedir conselho?",
      mode: "debochado",
      timestamp: "Agora",
    },
  ]);
  const [inputText, setInputText] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [thinkingQuote, setThinkingQuote] = useState("");
  const [speakingMessageId, setSpeakingMessageId] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [reactions, setReactions] = useState<Record<string, string>>({});

  const chatContainerRef = useRef<HTMLDivElement>(null);
  const isFirstRender = useRef(true);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const mode = CHAOS_MODES[currentMode];

  // Auto-scroll chat internally to bottom without hijacking window scroll
  const scrollToBottom = useCallback(() => {
    if (chatContainerRef.current) {
      chatContainerRef.current.scrollTo({
        top: chatContainerRef.current.scrollHeight,
        behavior: isFirstRender.current ? "instant" : "smooth",
      });
    }
  }, []);

  useEffect(() => {
    if (isFirstRender.current) {
      isFirstRender.current = false;
      return;
    }
    scrollToBottom();
  }, [messages, isLoading, thinkingQuote, scrollToBottom]);

  // Main Send Message Handler
  const handleSendMessage = useCallback(
    async (textToSend?: string) => {
      const text = textToSend || inputText;
      if (!text.trim() || isLoading) return;

      sounds.playBlip();
      const userMsg: Message = {
        id: `user-${Date.now()}`,
        role: "user",
        content: text.trim(),
        timestamp: new Date().toLocaleTimeString("pt-BR", {
          hour: "2-digit",
          minute: "2-digit",
        }),
      };

      const nextHistory = [...messages, userMsg];
      setMessages(nextHistory);
      setInputText("");
      setIsLoading(true);
      const quotes = formatBanterForMode(currentMode);
      setThinkingQuote(quotes[0]);

      try {
        const payload = nextHistory.map((m) => ({
          role: m.role,
          content: m.content,
        }));

        const res = await fetch("/api/chat", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            messages: payload,
            mode: currentMode,
          }),
        });

        const data = await res.json();
        sounds.playMessageReceived();

        const modelMsg: Message = {
          id: `model-${Date.now()}`,
          role: "model",
          content: data.reply || "Tô aqui sem palavras pro tamanho da sua audácia.",
          mode: data.mode || currentMode,
          timestamp: new Date().toLocaleTimeString("pt-BR", {
            hour: "2-digit",
            minute: "2-digit",
          }),
        };

        setMessages((prev) => [...prev, modelMsg]);
      } catch (err) {
        console.error(err);
        setMessages((prev) => [
          ...prev,
          {
            id: `error-${Date.now()}`,
            role: "model",
            content:
              "Deu uma travada na Matrix aqui do meu cabeção. Mas resumindo: você ainda tá precisando tomar prumo na vida. Pergunta de novo aí!",
            mode: "debochado",
            timestamp: new Date().toLocaleTimeString("pt-BR", {
              hour: "2-digit",
              minute: "2-digit",
            }),
          },
        ]);
      } finally {
        setIsLoading(false);
      }
    },
    [inputText, isLoading, messages, currentMode]
  );

  // Consume incoming initial question from Hero or Suggestions
  useEffect(() => {
    if (initialQuestion && initialQuestion.trim().length > 0) {
      const q = initialQuestion.trim();
      const timer = setTimeout(() => {
        handleSendMessage(q);
        if (onQuestionConsumed) {
          onQuestionConsumed();
        }
      }, 50);
      return () => clearTimeout(timer);
    }
  }, [initialQuestion, handleSendMessage, onQuestionConsumed]);

  // Cycle thinking quotes during loading
  useEffect(() => {
    if (!isLoading) return;
    const quotes = formatBanterForMode(currentMode);
    let index = 0;

    const interval = setInterval(() => {
      index = (index + 1) % quotes.length;
      setThinkingQuote(quotes[index]);
    }, 2200);

    return () => clearInterval(interval);
  }, [isLoading, currentMode]);

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const toggleSpeak = (id: string, text: string) => {
    if (speakingMessageId === id) {
      stopSpeaking();
      setSpeakingMessageId(null);
    } else {
      setSpeakingMessageId(id);
      speakResendeText(text, () => {
        setSpeakingMessageId(null);
      });
    }
  };

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    sounds.playBlip();
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleClearChat = () => {
    stopSpeaking();
    sounds.playBlip();
    setMessages([
      {
        id: `reset-${Date.now()}`,
        role: "model",
        content:
          "Memória zerada! Pode confessar outra burrada que eu prometo não contar pra ninguém (só vou julgar mesmo).",
        mode: currentMode,
        timestamp: new Date().toLocaleTimeString("pt-BR", {
          hour: "2-digit",
          minute: "2-digit",
        }),
      },
    ]);
  };

  const handleReaction = (msgId: string, emoji: string) => {
    sounds.playBlip();
    setReactions((prev) => ({ ...prev, [msgId]: emoji }));
  };

  return (
    <section id="chat-lounge" className="py-20 relative bg-[#070312]">
      {/* Background Neon Spotlights */}
      <div className="absolute top-1/4 left-1/3 w-[500px] h-[500px] bg-purple-600/10 rounded-full blur-[140px] pointer-events-none" />
      <div className="absolute bottom-1/4 right-1/4 w-[500px] h-[500px] bg-cyan-600/10 rounded-full blur-[140px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Title */}
        <div className="text-center max-w-2xl mx-auto mb-10">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-purple-950/80 border border-purple-500/40 text-purple-300 text-xs font-semibold mb-3">
            <Bot className="w-3.5 h-3.5 text-cyan-400" />
            <span>LOUNGE DO RESENDE • AO VIVO</span>
          </div>
          <h2 className="text-3xl sm:text-5xl font-black text-white tracking-tight font-['Space_Grotesk'] mb-3">
            Converse com o{" "}
            <span className="bg-clip-text text-transparent bg-gradient-to-r from-purple-400 via-pink-400 to-cyan-300">
              Boneco
            </span>
          </h2>
          <p className="text-slate-300 text-sm sm:text-base">
            Mande suas dúvidas de amor, trampo, boletos ou decisões suspeitas. Ele
            responde em tempo real com a sabedoria das ruas.
          </p>
        </div>

        {/* Main Chat Interface Box */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left Column: Character Stage & Live Reactions */}
          <div className="lg:col-span-4 hidden lg:flex flex-col items-center sticky top-28 bg-[#110822]/90 border border-purple-900/40 rounded-3xl p-6 shadow-2xl backdrop-blur-md">
            {/* Character Avatar Stage */}
            <div className="relative w-48 h-64 mb-4 flex items-end justify-center">
              <div className="absolute inset-0 bg-gradient-to-t from-purple-600/30 to-cyan-400/15 rounded-full blur-2xl" />

              {/* Pedestal */}
              <div className="absolute bottom-0 w-36 h-6 rounded-full bg-[#1e0e3b] border border-cyan-400/50 shadow-[0_0_20px_rgba(6,182,212,0.5)]" />

              <Image
                src="/assets/aistudio/romulo_funko_9b7f39ed.png"
                alt="Resende Funko Pop Falando"
                width={200}
                height={280}
                className={`object-contain max-h-60 relative z-10 transition-transform duration-300 ${
                  isLoading ? "scale-105 animate-pulse" : "hover:scale-105"
                }`}
                style={{ width: "auto", height: "auto" }}
                referrerPolicy="no-referrer"
              />
            </div>

            {/* Status Indicator */}
            <div className="w-full flex items-center justify-between px-4 py-2.5 rounded-2xl bg-[#0d061c] border border-purple-900/50 mb-4">
              <div className="flex items-center gap-2">
                <span
                  className={`w-2.5 h-2.5 rounded-full ${
                    isLoading ? "bg-amber-400 animate-ping" : "bg-emerald-400"
                  }`}
                />
                <span className="text-xs font-semibold text-slate-200">
                  {isLoading ? "Processando o deboche..." : "Pronto pro combate"}
                </span>
              </div>
              <span className="text-[11px] font-bold text-cyan-400 uppercase tracking-wider">
                {mode.name}
              </span>
            </div>

            {/* Personality Quick Switcher */}
            <div className="w-full">
              <label className="text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-2 block">
                Alterar Humor do Funko:
              </label>
              <div className="grid grid-cols-2 gap-2">
                {(["debochado", "sincerao", "duvidoso", "caos"] as ChaosModeId[]).map(
                  (mId) => {
                    const m = CHAOS_MODES[mId];
                    const isActive = currentMode === mId;
                    return (
                      <button
                        key={mId}
                        onClick={() => {
                          sounds.playBlip();
                          onSelectMode(mId);
                        }}
                        className={`px-3 py-2 rounded-xl text-xs font-semibold border text-left transition-all ${
                          isActive
                            ? `${m.pillColor} shadow-md`
                            : "bg-[#0b0517] text-slate-400 border-purple-950 hover:border-purple-800 hover:text-slate-200"
                        }`}
                      >
                        {m.name}
                      </button>
                    );
                  }
                )}
              </div>
            </div>

            {/* Quick Humor Quote */}
            <div className="mt-5 p-3 rounded-xl bg-purple-950/40 border border-purple-800/30 text-xs text-purple-300/90 italic text-center w-full">
              “{mode.sampleQuote}”
            </div>
          </div>

          {/* Right Column: Chat Console Container */}
          <div className="lg:col-span-8 w-full flex flex-col h-[650px] sm:h-[700px] rounded-3xl bg-[#0f0721]/95 border border-purple-800/40 shadow-2xl shadow-purple-950/40 backdrop-blur-xl overflow-hidden">
            {/* Chat Top Bar */}
            <div className="px-5 py-4 bg-[#140a2c]/90 border-b border-purple-900/40 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="relative w-9 h-9 rounded-xl bg-gradient-to-tr from-purple-600 to-cyan-400 p-[1.5px]">
                  <div className="w-full h-full bg-[#120726] rounded-[10px] overflow-hidden">
                    <Image
                      src="/assets/aistudio/romulo_funko_9b7f39ed.png"
                      alt="Resende"
                      width={36}
                      height={36}
                      className="object-cover object-top scale-125 translate-y-1"
                      referrerPolicy="no-referrer"
                    />
                  </div>
                  <span className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 bg-emerald-400 rounded-full border border-[#0f0721]" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="font-bold text-white text-sm sm:text-base font-['Space_Grotesk']">
                      Resende
                    </h3>
                    <span className="px-2 py-0.5 text-[10px] font-bold rounded-full bg-cyan-950 text-cyan-300 border border-cyan-500/30">
                      {mode.name}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400">{mode.tagline}</p>
                </div>
              </div>

              {/* Chat Actions */}
              <div className="flex items-center gap-2">
                <button
                  onClick={handleClearChat}
                  aria-label="Limpar histórico de conversa"
                  className="px-3 py-1.5 rounded-xl bg-purple-950/60 border border-purple-700/40 text-purple-300 text-xs font-semibold hover:bg-purple-900/60 hover:text-white transition-colors flex items-center gap-1.5"
                  title="Reiniciar conversa"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Limpar</span>
                </button>
              </div>
            </div>

            {/* Chat Messages Scrollable Area */}
            <div
              ref={chatContainerRef}
              className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-5"
            >
              {messages.map((msg) => {
                const isUser = msg.role === "user";
                return (
                  <div
                    key={msg.id}
                    className={`flex items-start gap-3 ${
                      isUser ? "flex-row-reverse" : "flex-row"
                    }`}
                  >
                    {/* Avatar */}
                    {!isUser ? (
                      <div className="shrink-0 w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-[#1d0d3b] border border-purple-500/40 overflow-hidden relative shadow-md">
                        <Image
                          src="/assets/aistudio/romulo_funko_9b7f39ed.png"
                          alt="Resende Avatar"
                          width={36}
                          height={36}
                          className="object-cover object-top scale-125 translate-y-1"
                          referrerPolicy="no-referrer"
                        />
                      </div>
                    ) : (
                      <div className="shrink-0 w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-gradient-to-tr from-cyan-600 to-indigo-600 flex items-center justify-center text-white text-xs font-bold shadow-md">
                        <User className="w-4 h-4" />
                      </div>
                    )}

                    {/* Bubble */}
                    <div
                      className={`max-w-[85%] sm:max-w-[78%] rounded-2xl p-4 sm:p-5 relative ${
                        isUser
                          ? "bg-gradient-to-r from-purple-700 to-indigo-700 text-white shadow-lg shadow-purple-900/30 rounded-tr-sm"
                          : "bg-[#180c33]/90 border border-purple-800/40 text-slate-100 shadow-xl shadow-purple-950/20 rounded-tl-sm backdrop-blur-sm"
                      }`}
                    >
                      {/* Message Content */}
                      <div className="text-sm sm:text-base leading-relaxed whitespace-pre-line font-normal">
                        {msg.content}
                      </div>

                      {/* Model Message Tools & Reactions */}
                      {!isUser && (
                        <div className="mt-3 pt-3 border-t border-purple-900/40 flex items-center justify-between text-xs text-slate-400">
                          {/* Speech & Copy */}
                          <div className="flex items-center gap-2">
                            <button
                              onClick={() => toggleSpeak(msg.id, msg.content)}
                              aria-label={
                                speakingMessageId === msg.id
                                  ? "Parar áudio do Resende"
                                  : "Ouvir Resende falar"
                              }
                              className={`p-1.5 rounded-lg border transition-all ${
                                speakingMessageId === msg.id
                                  ? "bg-cyan-500 text-white border-cyan-400 shadow-sm shadow-cyan-500/40"
                                  : "bg-purple-950/60 border-purple-700/30 text-purple-300 hover:text-white hover:bg-purple-900/60"
                              }`}
                              title={
                                speakingMessageId === msg.id
                                  ? "Parar de falar"
                                  : "Ouvir voz do Resende"
                              }
                            >
                              {speakingMessageId === msg.id ? (
                                <VolumeX className="w-3.5 h-3.5 animate-pulse" />
                              ) : (
                                <Volume2 className="w-3.5 h-3.5" />
                              )}
                            </button>

                            <button
                              onClick={() => handleCopy(msg.id, msg.content)}
                              aria-label="Copiar resposta"
                              className="p-1.5 rounded-lg bg-purple-950/60 border border-purple-700/30 text-purple-300 hover:text-white hover:bg-purple-900/60 transition-all"
                              title="Copiar tirada"
                            >
                              {copiedId === msg.id ? (
                                <Check className="w-3.5 h-3.5 text-emerald-400" />
                              ) : (
                                <Copy className="w-3.5 h-3.5" />
                              )}
                            </button>
                          </div>

                          {/* Reaction Emojis */}
                          <div className="flex items-center gap-1">
                            {["😂", "💀", "🔥", "👏"].map((emoji) => {
                              const isReacted = reactions[msg.id] === emoji;
                              return (
                                <button
                                  key={emoji}
                                  onClick={() => handleReaction(msg.id, emoji)}
                                  className={`px-1.5 py-0.5 rounded-lg transition-transform hover:scale-125 ${
                                    isReacted
                                      ? "bg-purple-800 text-base"
                                      : "opacity-70 hover:opacity-100"
                                  }`}
                                  title={`Reagir com ${emoji}`}
                                >
                                  {emoji}
                                </button>
                              );
                            })}
                          </div>
                        </div>
                      )}

                      {/* Timestamp */}
                      <span className="block text-[10px] text-slate-400/60 mt-1 text-right">
                        {msg.timestamp}
                      </span>
                    </div>
                  </div>
                );
              })}

              {/* Thinking / Loading Banter Bubble */}
              {isLoading && (
                <div className="flex items-start gap-3">
                  <div className="shrink-0 w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-[#1d0d3b] border border-cyan-400/60 overflow-hidden relative shadow-lg shadow-cyan-500/20 animate-pulse">
                    <Image
                      src="/assets/aistudio/romulo_funko_9b7f39ed.png"
                      alt="Resende Pensando"
                      width={36}
                      height={36}
                      className="object-cover object-top scale-125 translate-y-1"
                      referrerPolicy="no-referrer"
                    />
                  </div>
                  <div className="rounded-2xl p-4 bg-[#1a0c38] border border-cyan-500/50 text-cyan-200 text-sm shadow-xl flex items-center gap-3">
                    <Loader2 className="w-4 h-4 animate-spin text-cyan-400 shrink-0" />
                    <span className="font-medium italic">
                      {thinkingQuote || "Avaliando o tamanho do mico..."}
                    </span>
                  </div>
                </div>
              )}
            </div>

            {/* Quick Follow-up Suggestion Pills */}
            <div className="px-4 py-2 bg-[#120726]/80 border-t border-purple-900/30 flex items-center gap-2 overflow-x-auto no-scrollbar">
              <span className="text-[11px] font-bold text-slate-400 shrink-0">
                Puxar assunto:
              </span>
              {[
                "Dá pra piorar?",
                "Me dá outro conselho",
                "E se eu mentir um pouco?",
                "Como resolver isso com R$ 20?",
              ].map((pill) => (
                <button
                  key={pill}
                  onClick={() => handleSendMessage(pill)}
                  disabled={isLoading}
                  className="shrink-0 px-2.5 py-1 rounded-full bg-purple-950/70 border border-purple-800/40 text-purple-300 text-xs hover:border-cyan-400 hover:text-white transition-all disabled:opacity-50"
                >
                  {pill}
                </button>
              ))}
            </div>

            {/* Chat Input Container */}
            <div className="p-3 sm:p-4 bg-[#14092e] border-t border-purple-900/50">
              <div className="flex items-end gap-2 bg-[#0c0419] rounded-2xl border border-purple-700/50 p-2 focus-within:border-cyan-400 focus-within:shadow-[0_0_20px_rgba(6,182,212,0.3)] transition-all">
                <textarea
                  ref={textareaRef}
                  value={inputText}
                  onChange={(e) => setInputText(e.target.value)}
                  onKeyDown={handleKeyDown}
                  placeholder={`Manda a pergunta pro Resende (${mode.name})...`}
                  rows={1}
                  aria-label="Mensagem para o Resende"
                  className="w-full bg-transparent px-3 py-2 text-sm sm:text-base text-white placeholder-slate-500 focus:outline-none resize-none max-h-32"
                />

                <button
                  onClick={() => handleSendMessage()}
                  disabled={!inputText.trim() || isLoading}
                  aria-label="Enviar mensagem para o Resende"
                  className="shrink-0 p-2.5 sm:px-4 sm:py-2.5 rounded-xl bg-gradient-to-r from-purple-600 via-pink-600 to-cyan-500 text-white font-bold text-sm shadow-md transition-all hover:scale-105 active:scale-95 disabled:opacity-40 disabled:hover:scale-100"
                >
                  <Send className="w-4 h-4" />
                </button>
              </div>
              <div className="flex items-center justify-between px-2 pt-1.5 text-[10px] text-slate-400">
                <span>Enter para enviar • Shift + Enter para quebrar linha</span>
                <span className="hidden sm:inline">IA Gemini 3.8 Flash • Humor Brasileiro</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
