"use client";

import React from "react";
import Image from "next/image";
import { Heart } from "lucide-react";

export default function Footer() {
  return (
    <footer className="w-full bg-[#06020c] border-t border-purple-900/40 py-4 px-4 sm:px-6 lg:px-8 mt-auto z-30">
      <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2.5 text-xs text-slate-400">
        <div className="flex items-center gap-2.5">
          <div className="w-6 h-6 rounded-lg bg-gradient-to-tr from-purple-600 to-cyan-400 p-[1px] overflow-hidden">
            <Image
              src="/assets/aistudio/romulo_funko_9b7f39ed.png"
              alt="Romuloko"
              width={24}
              height={24}
              className="object-cover object-top scale-125"
              style={{ width: "auto", height: "auto" }}
              referrerPolicy="no-referrer"
            />
          </div>
          <span className="font-bold text-slate-200 font-['Space_Grotesk']">
            ROMULOKO © 2026
          </span>
          <span className="text-slate-400">• O Funko mais sincero do Brasil</span>
        </div>

        <div className="flex items-center gap-1.5 text-slate-400 text-[11px]">
          <span>Criado com</span>
          <Heart className="w-3.5 h-3.5 text-pink-500 fill-pink-500 inline" />
          <span>e humor brasileiro sem filtro.</span>
        </div>
      </div>
    </footer>
  );
}
