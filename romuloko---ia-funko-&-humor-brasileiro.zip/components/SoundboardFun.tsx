"use client";

import React, { useState } from "react";
import Image from "next/image";
import confetti from "canvas-confetti";
import { Flame, Sparkles, Volume2, AlertOctagon, RotateCw } from "lucide-react";
import { sounds, speakResendeText } from "@/lib/audio-effects";

export default function SoundboardFun() {
  const [currentPunchline, setCurrentPunchline] = useState<string | null>(null);
  const [isPressing, setIsPressing] = useState(false);

  const PUNCHLINES = [
    "Se conselho fosse bom, o Resende cobrava em criptomoeda e não tava aqui te ouvindo de graça!",
    "Você não precisa de terapia hoje, precisa de R$ 500 no Pix e 12 horas de sono ininterrupto.",
    "Atenção: sua decisão atual tem 98% de chance de virar áudio de desabafo no grupo dos amigos.",
    "Boleto não tem sentimentos, mas adora estragar os seus às 17h59 de uma sexta-feira.",
    "Mandar mensagem pro ex de madrugada é assinar atestado de carência com firma reconhecida em cartório.",
    "Trabalhe enquanto eles dormem e acorde com olheiras que nem filtro do Instagram consegue disfarçar.",
  ];

  const triggerChaosButton = () => {
    setIsPressing(true);
    sounds.playChaosWarning();

    try {
      confetti({
        particleCount: 65,
        spread: 80,
        origin: { y: 0.7 },
        colors: ["#ec4899", "#8b5cf6", "#06b6d4", "#fbbf24"],
      });
    } catch {
      // Ignore
    }

    const random = PUNCHLINES[Math.floor(Math.random() * PUNCHLINES.length)];
    setCurrentPunchline(random);
    speakResendeText(random);

    setTimeout(() => setIsPressing(false), 300);
  };

  return (
    <section className="py-20 relative bg-[#090416] overflow-hidden">
      {/* Glow effect */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[300px] bg-red-600/10 rounded-full blur-[140px] pointer-events-none" />

      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
        
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-red-950/80 border border-red-500/40 text-red-300 text-xs font-semibold mb-4">
          <AlertOctagon className="w-3.5 h-3.5 text-red-400" />
          <span>ÁREA DE ALTO RISCO DE VERDADES</span>
        </div>

        <h2 className="text-3xl sm:text-5xl font-black text-white tracking-tight font-['Space_Grotesk'] mb-4">
          O Botão{" "}
          <span className="bg-clip-text text-transparent bg-gradient-to-r from-red-500 via-pink-500 to-amber-400">
            Proibido do Caos
          </span>
        </h2>
        <p className="text-slate-300 text-sm sm:text-base max-w-xl mx-auto mb-10">
          Você foi avisado. Aperte o botão abaixo para invocar uma pedrada
          aleatória do Resende com voz e efeitos.
        </p>

        {/* Big Interactive Button */}
        <div className="flex flex-col items-center justify-center">
          <button
            onClick={triggerChaosButton}
            aria-label="Apertar botão proibido do caos para ouvir uma tirada aleatória"
            className={`relative group w-48 h-48 sm:w-56 sm:h-56 rounded-full bg-gradient-to-b from-red-500 via-rose-600 to-red-800 p-3 shadow-[0_0_50px_rgba(239,68,68,0.5)] border-4 border-red-400/60 transition-transform active:scale-95 cursor-pointer focus:outline-none ${
              isPressing ? "scale-90" : "hover:scale-105"
            }`}
          >
            <div className="w-full h-full rounded-full bg-gradient-to-b from-[#2a0815] to-[#120309] flex flex-col items-center justify-center p-4 border-2 border-red-500/40 shadow-inner">
              <Flame className="w-10 h-10 sm:w-12 sm:h-12 text-red-500 mb-2 animate-bounce group-hover:scale-110 transition-transform" />
              <span className="text-sm sm:text-base font-extrabold text-white uppercase tracking-wider font-['Space_Grotesk'] leading-tight">
                NÃO APERTE
              </span>
              <span className="text-[10px] text-red-300/80 font-semibold mt-1">
                (Aperte agora)
              </span>
            </div>
          </button>

          {/* Punchline Display Modal / Card */}
          {currentPunchline && (
            <div className="mt-8 max-w-2xl w-full p-6 rounded-3xl bg-[#160722] border-2 border-red-500/50 shadow-2xl shadow-red-950/50 animate-in fade-in slide-in-from-bottom-4 duration-300">
              <div className="flex items-center justify-center gap-2 text-xs font-bold text-red-400 uppercase tracking-wider mb-2">
                <Sparkles className="w-4 h-4" />
                <span>Pílula de Sabedoria do Funko</span>
              </div>
              <p className="text-lg sm:text-xl font-bold text-white font-['Space_Grotesk'] leading-relaxed mb-4">
                &ldquo;{currentPunchline}&rdquo;
              </p>
              <div className="flex items-center justify-center gap-3">
                <button
                  onClick={() => speakResendeText(currentPunchline)}
                  className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-purple-950/80 border border-purple-700/50 text-xs font-bold text-purple-200 hover:text-white hover:bg-purple-900 transition-colors"
                >
                  <Volume2 className="w-4 h-4 text-cyan-400" />
                  <span>Repetir Áudio</span>
                </button>
                <button
                  onClick={triggerChaosButton}
                  className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-red-950/80 border border-red-700/50 text-xs font-bold text-red-200 hover:text-white hover:bg-red-900 transition-colors"
                >
                  <RotateCw className="w-4 h-4 text-amber-400" />
                  <span>Outra Pedrada</span>
                </button>
              </div>
            </div>
          )}
        </div>

      </div>
    </section>
  );
}
