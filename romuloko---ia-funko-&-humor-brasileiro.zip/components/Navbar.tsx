"use client";

import React, { useState } from "react";
import Image from "next/image";
import { Volume2, VolumeX, RotateCcw } from "lucide-react";
import { sounds, stopRomulokoVoice } from "@/lib/audio-effects";
import { RomulokoMood, MOOD_CONFIGS } from "@/lib/romuloko";

interface NavbarProps {
  onClearChat: () => void;
  isGenerating?: boolean;
  mood?: RomulokoMood;
}

export default function Navbar({
  onClearChat,
  isGenerating = false,
  mood = "normal",
}: NavbarProps) {
  const [audioEnabled, setAudioEnabled] = useState(true);

  const toggleAudio = () => {
    const next = !audioEnabled;
    setAudioEnabled(next);
    sounds.enabled = next;
    if (!next) {
      stopRomulokoVoice();
    } else {
      sounds.playBlip();
    }
  };

  const currentMoodConfig = MOOD_CONFIGS[mood] || MOOD_CONFIGS.normal;

  return (
    <header className="w-full bg-[#0b0618]/95 backdrop-blur-md border-b border-purple-900/40 py-2 sm:py-3 px-3 sm:px-6 z-40 shrink-0 sticky top-0">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-2">
        
        {/* Brand / Compact Reactive Funko Avatar */}
        <div className="flex items-center gap-2.5 sm:gap-3 min-w-0">
          
          {/* Reactive Avatar Container */}
          <div className="relative shrink-0">
            <div
              className={`relative w-10 h-10 sm:w-11 sm:h-11 rounded-2xl bg-gradient-to-br from-purple-600 via-pink-600 to-cyan-400 p-[2px] transition-all duration-300 ${
                mood === "pensando"
                  ? "ring-2 ring-cyan-400 shadow-[0_0_18px_rgba(6,182,212,0.8)]"
                  : mood === "rindo"
                  ? "ring-2 ring-amber-400 shadow-[0_0_18px_rgba(251,191,36,0.8)]"
                  : mood === "debochando"
                  ? "ring-2 ring-fuchsia-400 shadow-[0_0_18px_rgba(232,121,249,0.8)]"
                  : mood === "surpreso"
                  ? "ring-2 ring-rose-400 shadow-[0_0_20px_rgba(244,63,94,0.85)] scale-105"
                  : "shadow-md shadow-purple-600/30"
              }`}
            >
              <div className="w-full h-full bg-[#0d071d] rounded-[14px] flex items-center justify-center overflow-hidden relative">
                <Image
                  src="/assets/aistudio/romulo_funko_9b7f39ed.png"
                  alt="Avatar Romuloko Funko"
                  width={44}
                  height={44}
                  priority
                  className={`object-cover object-top scale-125 translate-y-1 transition-transform duration-300 ${
                    mood === "pensando"
                      ? "animate-pulse"
                      : mood === "rindo"
                      ? "animate-bounce"
                      : mood === "debochando"
                      ? "rotate-3 scale-130"
                      : mood === "surpreso"
                      ? "scale-140 -translate-y-0.5"
                      : ""
                  }`}
                  style={{ width: "auto", height: "auto" }}
                  referrerPolicy="no-referrer"
                />
              </div>

              {/* Status Ping Beacon */}
              <span className="absolute -top-1 -right-1 w-3 h-3 bg-emerald-400 rounded-full border-2 border-[#0d071d] animate-ping" />
              <span className="absolute -top-1 -right-1 w-3 h-3 bg-emerald-400 rounded-full border-2 border-[#0d071d]" />
            </div>

            {/* Reaction Emoji Floating Badge */}
            <span
              className={`absolute -bottom-1 -right-1 text-xs transition-transform duration-200 select-none ${
                mood !== "normal" ? "scale-110" : "scale-90 opacity-80"
              }`}
              title={currentMoodConfig.label}
            >
              {currentMoodConfig.emoji}
            </span>
          </div>

          {/* Title & Contextual Mood Label */}
          <div className="min-w-0">
            <div className="flex items-center gap-1.5 sm:gap-2">
              <span className="text-lg sm:text-2xl font-black tracking-wider bg-clip-text text-transparent bg-gradient-to-r from-purple-200 via-pink-200 to-cyan-300 font-['Space_Grotesk'] truncate">
                ROMULOKO
              </span>
              
              {/* Dynamic Mood Status Tag */}
              <span
                className={`px-1.5 sm:px-2 py-0.5 text-[9px] sm:text-[10px] font-bold uppercase tracking-wider rounded-full border transition-all duration-300 whitespace-nowrap ${currentMoodConfig.colorClass}`}
              >
                {mood === "normal" ? "IA 220V" : currentMoodConfig.badge}
              </span>
            </div>

            <p className="text-[11px] text-purple-300/70 hidden sm:block truncate">
              O Funko mais sincero, ácido e imprevisível do Brasil
            </p>
          </div>
        </div>

        {/* Right Action Buttons */}
        <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
          {/* Audio Sound Toggle */}
          <button
            onClick={toggleAudio}
            aria-label={audioEnabled ? "Desativar efeitos sonoros" : "Ativar efeitos sonoros"}
            className={`min-w-[38px] min-h-[38px] sm:min-w-[40px] sm:min-h-[40px] p-2 sm:px-3 sm:py-2 rounded-xl border transition-all flex items-center justify-center gap-1.5 text-xs font-semibold ${
              audioEnabled
                ? "bg-purple-950/70 border-purple-500/40 text-purple-200 shadow-sm shadow-purple-500/20 hover:border-purple-400"
                : "bg-slate-900/60 border-slate-700/50 text-slate-500 hover:text-slate-300"
            } active:scale-95`}
            title={audioEnabled ? "Sons ativados (clique para mutar)" : "Sons mutados"}
          >
            {audioEnabled ? <Volume2 className="w-4 h-4 text-cyan-400" /> : <VolumeX className="w-4 h-4" />}
            <span className="hidden md:inline">{audioEnabled ? "Áudio ON" : "Áudio OFF"}</span>
          </button>

          {/* Reset / Clear Conversation Button */}
          <button
            onClick={onClearChat}
            disabled={isGenerating}
            aria-label="Reiniciar conversa com Romuloko"
            className="min-w-[38px] min-h-[38px] sm:min-w-[40px] sm:min-h-[40px] p-2 sm:px-3.5 sm:py-2 rounded-xl bg-purple-950/70 border border-purple-800/50 text-purple-200 hover:text-white hover:bg-purple-900/70 hover:border-purple-500/50 transition-all flex items-center justify-center gap-1.5 text-xs font-semibold shadow-sm active:scale-95 disabled:opacity-50"
            title="Limpar histórico e começar nova conversa"
          >
            <RotateCcw className="w-4 h-4 text-pink-400" />
            <span className="hidden sm:inline">Nova Conversa</span>
          </button>
        </div>

      </div>
    </header>
  );
}
