"use client";

import React from "react";
import {
  HeartCrack,
  Flame,
  HelpCircle,
  Zap,
  MessageCircleWarning,
  Sparkles,
  ArrowUpRight,
  Send,
} from "lucide-react";
import { SUGGESTIONS, SuggestionItem, ChaosModeId } from "@/lib/chaos-modes";
import { sounds } from "@/lib/audio-effects";

interface SuggestionCardsProps {
  onSelectSuggestion: (suggestion: SuggestionItem) => void;
  currentMode: ChaosModeId;
}

export default function SuggestionCards({
  onSelectSuggestion,
  currentMode,
}: SuggestionCardsProps) {
  const getIcon = (iconName: string) => {
    switch (iconName) {
      case "HeartCrack":
        return <HeartCrack className="w-5 h-5 text-rose-400" />;
      case "Flame":
        return <Flame className="w-5 h-5 text-amber-400" />;
      case "HelpCircle":
        return <HelpCircle className="w-5 h-5 text-purple-400" />;
      case "Zap":
        return <Zap className="w-5 h-5 text-cyan-400" />;
      case "MessageCircleWarning":
        return <MessageCircleWarning className="w-5 h-5 text-pink-400" />;
      case "Sparkles":
        return <Sparkles className="w-5 h-5 text-emerald-400" />;
      default:
        return <Sparkles className="w-5 h-5 text-purple-400" />;
    }
  };

  const handleCardClick = (item: SuggestionItem) => {
    sounds.playBlip();
    onSelectSuggestion(item);
  };

  return (
    <section id="perguntas-engracadas" className="py-20 relative bg-[#0a0516]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-4">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-950/80 border border-cyan-500/30 text-cyan-300 text-xs font-semibold mb-3">
              <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
              <span>TESTE O DIAGNÓSTICO DO BONECO</span>
            </div>
            <h2 className="text-3xl sm:text-5xl font-extrabold text-white tracking-tight font-['Space_Grotesk']">
              Sugestões que Vão{" "}
              <span className="bg-clip-text text-transparent bg-gradient-to-r from-cyan-400 via-pink-400 to-purple-400">
                Alugar um Triplex
              </span>{" "}
              na sua Mente
            </h2>
          </div>
          <p className="text-slate-400 text-sm sm:text-base max-w-md">
            Clique em qualquer card para disparar a pergunta direto para o chat
            do Resende com o humor correspondente.
          </p>
        </div>

        {/* Suggestion Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {SUGGESTIONS.map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => handleCardClick(item)}
              aria-label={`Fazer a pergunta: ${item.title}`}
              className="text-left group relative rounded-2xl bg-[#120826]/90 border border-purple-900/50 p-6 cursor-pointer hover:border-cyan-400/70 hover:bg-[#180a34] hover:shadow-[0_0_35px_rgba(6,182,212,0.25)] transition-all duration-300 flex flex-col justify-between"
            >
              {/* Card Top */}
              <div>
                <div className="flex items-center justify-between mb-4">
                  <div className="w-11 h-11 rounded-xl bg-purple-950/90 border border-purple-700/40 flex items-center justify-center group-hover:scale-110 transition-transform">
                    {getIcon(item.iconName)}
                  </div>
                  <span className="px-2.5 py-1 rounded-full text-[11px] font-semibold bg-purple-900/40 text-purple-300 border border-purple-700/30">
                    {item.tag}
                  </span>
                </div>

                <h3 className="text-xl font-bold text-white mb-2 group-hover:text-cyan-300 transition-colors font-['Space_Grotesk'] flex items-center justify-between">
                  <span>{item.title}</span>
                  <ArrowUpRight className="w-4 h-4 opacity-50 group-hover:opacity-100 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-all text-cyan-400" />
                </h3>

                <p className="text-xs text-slate-400 italic mb-4">
                  &ldquo;{item.reactionHint}&rdquo;
                </p>
              </div>

              {/* Card Bottom CTA */}
              <div className="pt-4 border-t border-purple-950/80 flex items-center justify-between text-xs font-semibold">
                <span className="text-purple-400/80 group-hover:text-purple-300">
                  Modo: <span className="capitalize">{item.mode}</span>
                </span>
                <span className="flex items-center gap-1.5 text-cyan-400 group-hover:translate-x-1 transition-transform">
                  <span>Perguntar</span>
                  <Send className="w-3.5 h-3.5" />
                </span>
              </div>
            </button>
          ))}
        </div>
      </div>
    </section>
  );
}
